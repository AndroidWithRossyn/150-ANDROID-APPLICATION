# NielsenSampleApp

Nielsen Sample App requires a number of configurations before this application can run

1. VisualOn Integration.  Please talk to your CSM for VisualOn integration for the Nielsen Integration
2. Nielsen Libraries.   Please go to Nielsen's engineering forum to download Nielsen Libraries. http://engineeringforum.nielsen.com/sdk/developers/
   Ooyala only ensures playback on one version of Nielsen Libraries.  see the /vendor/Nielsen folder for information on tested library
