package com.ooyala.sample.utils;

public interface NavigatedbackToAppListener {
  public void onNavigatedBackToApp();
}
