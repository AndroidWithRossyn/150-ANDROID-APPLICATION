package com.ooyala.sample.utils;

import com.adobe.adobepass.accessenabler.models.Mvpd;

public interface MvpdSelectedListener {
  public void onMvpdSelected(Mvpd mvpd);
}
