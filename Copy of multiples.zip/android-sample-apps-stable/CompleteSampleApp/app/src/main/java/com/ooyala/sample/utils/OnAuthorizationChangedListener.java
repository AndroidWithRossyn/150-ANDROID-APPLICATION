package com.ooyala.sample.utils;

public interface OnAuthorizationChangedListener {
  public void authChanged(Boolean authorized);
}
