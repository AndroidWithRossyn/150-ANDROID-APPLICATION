# RecyclerView Sample App

This app shows how we currently support the OoyalaPlayer in a RecyclerView. The name of the app is misleading since it is called FullscreenSampleApp, but it only shows how to add OoyalaPlayers as items in a RecyclerView.

We'll change the name in the future.

## Requirements

1. Android Studio 2.3.2 or above
1. Android SDK installed
