# BottomNavigationView
This is a simple app showing how to add bottom navigation view in Kotlin.
<br><br>
<h2>Demo</h2>
<br>
<img src="sample.gif"/>