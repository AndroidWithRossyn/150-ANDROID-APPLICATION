# Kodein
Kodein is a painless dependency injector which can be easily used as replaceble for Dagger2 in small projects. In this project the singleton instance of Retrofit from InitApp file is provided as singelton all over app and injected in MainActivity by delegate properties.


