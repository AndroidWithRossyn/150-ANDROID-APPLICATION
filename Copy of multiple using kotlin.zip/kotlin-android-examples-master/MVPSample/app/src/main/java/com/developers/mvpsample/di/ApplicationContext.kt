package com.developers.mvpsample.di

import javax.inject.Qualifier

/**
 * Created by Amanjeet Singh on 6/2/18.
 */
@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class ApplicationContext