package com.developers.mvpsample.di

import javax.inject.Scope

/**
 * Created by Amanjeet Singh on 6/2/18.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerActivity