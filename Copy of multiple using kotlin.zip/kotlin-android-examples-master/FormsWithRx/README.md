# Forms using Rx
This is an example of using Rx in application of forms. It helps in enabling/disabling the button when the dezired conditions are met. When the conditions are met we set button enabled and as soon as they are not met we disable the button.<br>
RxJava Operators used:
<UL>
<LI>Zip</LI>
<LI>Map</LI>
<LI>Debounce</LI>
</UL>

Screenshots:
<br><br>
<img src="forms.gif"/>
