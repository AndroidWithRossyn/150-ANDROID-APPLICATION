package com.developers.databinding

/**
 * Created by Amanjeet Singh on 12/11/17.
 */
data class User(val name: String, val age: Int, val email: String)