# EmojiCompat
The aim of the EmojiCompat library is to try and ensure that devices are kept up to date with the latest emojis. It prevent devices to show text like these :
<br><br>
<img src="this.png"/>
<br><br>
<b>And safely show</b>
<img src="that.png"/>
<br><br>
Screenshots:
<br><br>
<img src="emoji.gif"/>
