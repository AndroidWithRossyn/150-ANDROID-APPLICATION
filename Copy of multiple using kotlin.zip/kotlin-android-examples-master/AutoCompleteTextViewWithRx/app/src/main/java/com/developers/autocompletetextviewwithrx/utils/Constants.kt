package com.developers.autocompletetextviewwithrx.utils

/**
 * Created by Amanjeet Singh on 2/12/17.
 */
class Constants{

    companion object {
        @JvmField
        val BASE_URL="https://maps.googleapis.com/maps/api/place/"
    }
}