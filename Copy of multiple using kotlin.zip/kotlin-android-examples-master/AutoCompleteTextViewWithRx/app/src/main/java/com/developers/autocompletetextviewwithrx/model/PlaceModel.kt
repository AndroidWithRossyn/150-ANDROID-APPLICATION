package com.developers.autocompletetextviewwithrx.model

/**
 * Created by Amanjeet Singh on 11/12/17.
 */
data class PlaceModel(val description: String = "", val placeId: String = "")