# AutoCompleteTextView Using Rx
This is an example of android AutoCompleteTextView by using RxJava with kotlin extensions.<br>It has implementation of different rx operators like debounce, filter, map etc.

Screenshots:
<br><br>
<img src="autogif.gif" width="250px" height="400px"/>
