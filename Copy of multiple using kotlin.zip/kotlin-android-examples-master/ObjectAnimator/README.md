# ObjectAnimators
Object Animators are the subclass of ValueAnimator but they make animating properties of views more easy.
<br><br>
<b>Screenshots:</b>
<br><br>
<img src="object.gif"/>
