# Jackson Kotlin Module
Jackson is module that adds support for serialization/deserialization of Kotlin classes and data classes. It can be integrated with the Retrofit as a converter so that ot can ease out the parsing of JSON from APIs.
<br><br>
<b>Screenshots:</b>
<br><br>
<img src="jackson.png" height="600px"/>
