# Moshi
Moshi is a modern JSON library which makes it easy to parse JSON into models and get results. It is believed that this out-performs GSON in various ways.
<br><br>
You can check out the docs by <b>SQUARE</b>:
https://github.com/square/moshi/ 
