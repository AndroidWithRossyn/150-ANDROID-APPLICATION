package com.developers.koin.main

/**
 * Created by Amanjeet Singh on 10/2/18.
 */
interface MainView {

    fun showMessage(hello: String)

    fun showError(error: String)
}