# Koin
Koin is a small library for writing dependency injection in a concise and pragmatic way. No proxy, no code generation, no introspection. Just DSL and functional Kotlin magic!. This is an example with demo using Koin
<br><br>
The simple steps to proceed with the library are:
<br><br>
<UL>
<LI>Declare</LI>
<LI>Start</LI>
<LI>Inject</LI>
</UL>
