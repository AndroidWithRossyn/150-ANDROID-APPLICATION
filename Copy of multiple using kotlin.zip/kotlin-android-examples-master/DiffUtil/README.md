# DiffUtil
This is an example of using DiffUtil CallBack to improve the updation of recycler view. DiffUtil is a utility class that can calculate the difference between two lists and output a list of update operations that converts the first list into the second one. This helps to improve the performance of your recycler view.

Screenshots:
<br><br>
<img src="diffGif.gif" width="250px" height="400px"/>
