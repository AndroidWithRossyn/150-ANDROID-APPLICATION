package com.developers.mvvmsample.di

import javax.inject.Qualifier

/**
 * Created by Amanjeet Singh on 10/2/18.
 */
@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class ApplicationContext