package com.developers.mvvmsample.di

import javax.inject.Scope

/**
 * Created by Amanjeet Singh on 10/2/18.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerActivity

