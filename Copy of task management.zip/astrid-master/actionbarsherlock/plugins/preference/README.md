ActionBarSherlock Plugin: Preference
====================================

This plugin provides support for an action bar enhanced preference screen
through an additional base activity, `SherlockPreferenceActivity`.
