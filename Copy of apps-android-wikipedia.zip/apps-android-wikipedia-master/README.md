### Wikipedia Android app

This repository contains the source code for the official Wikipedia Android app.

### Documentation

All documentation is kept on [our wiki](https://www.mediawiki.org/wiki/Wikimedia_Apps/Team/Wikipedia_Android_app_hacking). Check it out!