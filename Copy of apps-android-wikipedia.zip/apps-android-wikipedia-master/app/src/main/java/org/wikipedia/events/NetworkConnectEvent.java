package org.wikipedia.events;

public class NetworkConnectEvent {
}
