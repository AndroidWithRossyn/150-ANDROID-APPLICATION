package org.wikipedia.events;

public class SplitLargeListsEvent {
}
