package org.wikipedia.database;

public class ReadingListsContentProvider extends AppContentProvider {
}
