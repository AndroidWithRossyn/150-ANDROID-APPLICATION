package org.nutritionfacts.dailydozen.event;

public class ShowExplodingStarAnimation extends BaseEvent {
}
