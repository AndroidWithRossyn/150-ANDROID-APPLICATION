package org.nutritionfacts.dailydozen.event;

public class BaseEvent {
}
