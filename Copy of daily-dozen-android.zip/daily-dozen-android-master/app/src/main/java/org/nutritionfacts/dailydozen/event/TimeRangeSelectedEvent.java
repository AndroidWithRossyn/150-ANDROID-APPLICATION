package org.nutritionfacts.dailydozen.event;

public class TimeRangeSelectedEvent extends BaseEvent {
}
