package com.mp3cutter.ringtonemaker.Views;

public interface BubbleTextGetter {
    String getTextToShowInBubble(int pos);
}