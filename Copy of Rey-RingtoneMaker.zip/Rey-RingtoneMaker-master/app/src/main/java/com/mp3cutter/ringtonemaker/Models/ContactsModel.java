package com.mp3cutter.ringtonemaker.Models;

/**
 * Created by REYANSH on 4/13/2017.
 */

public class ContactsModel {
    public String mName;
    public String mContactId;

    public ContactsModel(String name, String contactId) {
        mName = name;
        mContactId = contactId;
    }
}
