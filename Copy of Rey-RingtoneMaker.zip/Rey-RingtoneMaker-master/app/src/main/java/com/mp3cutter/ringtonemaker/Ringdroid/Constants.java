package com.mp3cutter.ringtonemaker.Ringdroid;

/**
 * Created by REYANSH on 4/8/2017.
 */

public class Constants {
    public static String FILE_NAME = "FILE_NAME";
    public static String IS_RINGTONE = "IS_RINGTONE";
    public static String IS_ALARM = "IS_ALARM";
    public static String IS_NOTIFICATION = "IS_NOTIFICATION";
    public static String IS_MUSIC = "IS_MUSIC";
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS=45;
    public static final int REQUEST_ID_RECORD_AUDIO_PERMISSION=46;
    public static final int REQUEST_ID_READ_CONTACTS_PERMISSION=47;

}
