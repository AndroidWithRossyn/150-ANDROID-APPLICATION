android_snake_game
==================

Simple 2D Snake Game for Android

The game is like the game we use to play in our android phones in our 90s.A very good game to play and have time pass.

You need to also get https://github.com/codepath/android_simple_game_engine and copy the .java files
into this directory structure.
