package com.xiecc.seeWeather.common;

public enum Irrelevant {
    INSTANCE
}
