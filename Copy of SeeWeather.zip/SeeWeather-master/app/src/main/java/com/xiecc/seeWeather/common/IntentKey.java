package com.xiecc.seeWeather.common;

/**
 * Created by HugoXie on 2017/5/10.
 *
 * Email: Hugo3641@gmail.com
 * GitHub: https://github.com/xcc3641
 * Info:
 */

public class IntentKey {

    public static final String WEATHER = "weather";
}
