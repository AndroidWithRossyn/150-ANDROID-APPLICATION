package com.librelio.model.interfaces;

import android.support.v4.app.Fragment;

public interface DisplayableAsTab {
	
	public String getTitle();
	
	public Fragment getFragment();

}
