
package com.librelio.exception;

public class NoMemoryException extends DownloadException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public NoMemoryException(String message) {

        super(message);
        // TODO Auto-generated constructor stub
    }

}
