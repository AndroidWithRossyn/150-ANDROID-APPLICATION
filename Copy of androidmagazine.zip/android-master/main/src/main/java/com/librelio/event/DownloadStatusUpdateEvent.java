package com.librelio.event;

public class DownloadStatusUpdateEvent {

    public DownloadStatusUpdateEvent() {

    }
}
