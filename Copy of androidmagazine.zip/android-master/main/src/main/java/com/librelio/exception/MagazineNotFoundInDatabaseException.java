package com.librelio.exception;

public class MagazineNotFoundInDatabaseException extends Exception {

}
