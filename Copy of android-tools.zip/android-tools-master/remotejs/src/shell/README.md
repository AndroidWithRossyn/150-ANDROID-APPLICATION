RemoteJS shell application
===

What it is
---

It's the non-GUI version of RemoteJS.

How to build
---

Since it's written in the Python programming language, it doesn't require any build.
Python version 2.6 or above is required to run it though.
To run, type `python remotejs.py`.  For help on usage, add the `-h` or `--help` option.
