RemoteJS desktop application
===

What it is
---

It's the GUI version of RemoteJS.

How to build
---

It requires the [Qt](http://qt.nokia.com/) framework.
After the dependency is met, to build, run:

    qmake
    make
