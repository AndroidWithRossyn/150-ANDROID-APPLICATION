# ![Alt text](screenshots/supermarket.png "Supermarket price comparison app") simple Supermarket price comparison app

Android and PHP project


 * This project has a full tutorial here [http://www.kedevelopers.com/android/simple-supermarket-price-comparison-app-part-1/](http://www.kedevelopers.com/android/simple-supermarket-price-comparison-app-part-1/)

# Project includes

* Listing all products in DB
* Searching for products
* Adding products
* Adding supermarket users
* Basic CRUD operations
* After installation Admin logins Username: admin@supermarket.com 
                                  password: admin1234                                              


