# Basketball-Score-Tracker-App
This android application is used to track the score of two teams for example Lakers vs Clippers in a basketball game

<img width="597" alt="screen shot 2018-07-27 at 19 11 05" src="https://user-images.githubusercontent.com/39240687/43339329-f1977fe6-91d0-11e8-8804-9747bdda1a75.png">
