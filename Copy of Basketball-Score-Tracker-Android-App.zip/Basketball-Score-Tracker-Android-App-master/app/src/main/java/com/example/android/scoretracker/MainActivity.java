package com.example.android.scoretracker;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private int lakersScore = 0; //holds Lakers' score
    private int clippersScore = 0; //holds Clippers' score

    private TextView lakersTextView = null;
    private TextView clippersTextView = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initUI();
    }


    /* This method initialises the text views and buttons and sets
       OnClickListeners to the buttons
     */
    private void initUI() {
        lakersTextView = (TextView) findViewById(R.id.lakersScoreTextView);
        clippersTextView = (TextView) findViewById(R.id.clippersScoreTextView);
        Button lakersThreePointsButton = (Button) findViewById(R.id.lakersThreePointsButton);
        Button lakersTwoPointsButton = (Button) findViewById(R.id.lakersTwoPointsButton);
        Button lakersFreeThrowButton = (Button) findViewById(R.id.lakersFreeThrowButton);
        Button clippersThreePointsButton = (Button) findViewById(R.id.clippersThreePointsButton);
        Button clippersTwoPointsButton = (Button) findViewById(R.id.clippersTwoPointsButton);
        Button clippersFreeThrowButton = (Button) findViewById(R.id.clippersFreeThrowButton);
        Button resetScoresButton = (Button) findViewById(R.id.resetScoresButton);
        lakersThreePointsButton.setOnClickListener(this);
        lakersTwoPointsButton.setOnClickListener(this);
        lakersFreeThrowButton.setOnClickListener(this);
        clippersThreePointsButton.setOnClickListener(this);
        clippersTwoPointsButton.setOnClickListener(this);
        clippersFreeThrowButton.setOnClickListener(this);
        resetScoresButton.setOnClickListener(this);
    }


    //This method displays the Lakers' score
    public void displayLakersScore(int score) {
        lakersTextView.setText(String.valueOf(score));
    }


    /*
       This method increases the Lakers' score by three each time
       the Lakers' +3 points  button is pressed and it displays the new score
    */
    public void threePointsLakers() {
        lakersScore += 3;
        displayLakersScore(lakersScore);
    }


    /*
       This method increases the Lakers' score by two each time the Lakers'
       +2 points  button is pressed and it displays the new score
     */
    public void twoPointsLakers() {
        lakersScore += 2;
        displayLakersScore(lakersScore);
    }


    /* This method increases the Lakers' score by one each time the Lakers'
       Free Throw's button is pressed and it displays the new score
     */
    public void onePointLakers() {
        ++lakersScore;
        displayLakersScore(lakersScore);
    }


    //This method displays the Clippers' score
    public void displayClippersScore(int score) {
        clippersTextView.setText(String.valueOf(score));
    }


    /* This method increases the Clippers' score by three each time the Clippers'
       +3 button is pressed and it displays the new score
     */
    public void threePointsClippers() {
        clippersScore += 3;
        displayClippersScore(clippersScore);
    }

    /* This method increases the Clippers' score by two each time the Clippers'
       +2 points button is pressed and it displays the new score
    */
    public void twoPointsClippers() {
        clippersScore += 2;
        displayClippersScore(clippersScore);
    }


    /* This method increases the Clippers' score by one each time the Clippers'
       Free Throw's button is pressed and it displays the new score
     */
    public void onePointClippers() {
        clippersScore += 1;
        displayClippersScore(clippersScore);
    }


    //This method sets the Clippers and Lakers scores to zero each time the resetScores button is pressed and it displays the new score
    public void resetScores() {
        clippersScore = 0;
        lakersScore = 0;
        displayClippersScore(clippersScore);
        displayLakersScore(lakersScore);
    }


    //This calls the right method depending on which button is clicked.
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.lakersThreePointsButton:
                threePointsLakers();
                break;
            case R.id.lakersTwoPointsButton:
                twoPointsLakers();
                break;
            case R.id.lakersFreeThrowButton:
                onePointLakers();
                break;
            case R.id.clippersThreePointsButton:
                threePointsClippers();
                break;
            case R.id.clippersTwoPointsButton:
                twoPointsClippers();
                break;
            case R.id.clippersFreeThrowButton:
                onePointClippers();
                break;
            case R.id.resetScoresButton:
                resetScores();
                break;
        }

    }
}
