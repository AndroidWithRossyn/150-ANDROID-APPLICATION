package com.example.Aphexams;

public class Global {
    
	public static  String qu,ve;
    
}
