package co.tinode.tindroid.db;

/**
 * Local users
 */
public class StoredAccount {
    public Long id;
    public String uid;
}
