package co.tinode.tinodesdk;

/**
 * Attempt to modify a topic which exists only locally.
 */
public class NotSynchronizedException extends IllegalStateException {
}
