package co.tinode.tinodesdk.model;

/**
 * Part of Meta server response
 */

public class DelValues {
    public Integer clear;
    public MsgDelRange[] delseq;

    public DelValues() {}
}
