package co.tinode.tinodesdk;

/**
 * Attempt to interact with a topic without subscribing first
 */
public class NotSubscribedException extends IllegalStateException {
}
