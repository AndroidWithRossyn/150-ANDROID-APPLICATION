package co.tinode.tinodesdk.model;

public class AccessChange {
    public String want;
    public String given;

    public AccessChange() {
    }
}
