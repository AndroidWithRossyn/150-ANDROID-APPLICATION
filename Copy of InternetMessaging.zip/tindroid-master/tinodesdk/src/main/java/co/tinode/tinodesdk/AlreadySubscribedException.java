package co.tinode.tinodesdk;

/**
 * Thrown when the user is already subscribed to topic.
 */
public class AlreadySubscribedException extends IllegalStateException {
}
