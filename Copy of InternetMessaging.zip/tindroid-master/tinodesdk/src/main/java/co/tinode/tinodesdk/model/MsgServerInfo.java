package co.tinode.tinodesdk.model;

/**
 * Info packet
 */
public class MsgServerInfo {
    public String topic;
    public String from;
    public String what;
    public Integer seq;

    public MsgServerInfo() {
    }
}
