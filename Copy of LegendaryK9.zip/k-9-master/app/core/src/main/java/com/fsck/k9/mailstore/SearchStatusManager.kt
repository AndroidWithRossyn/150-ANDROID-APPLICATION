package com.fsck.k9.mailstore

class SearchStatusManager {
    var isActive = false
}
