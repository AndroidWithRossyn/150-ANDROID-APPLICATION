package com.fsck.k9;

public interface BaseAccount {
    String getEmail();
    void setEmail(String email);
    String getDescription();
    void setDescription(String description);
    String getUuid();
}
