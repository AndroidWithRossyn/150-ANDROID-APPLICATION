# Demo MultipleContacts

MultipleContacts demonstrates multi-auto-completion with contacts.

The user can enter several comma separated names and auto-completion is suggested for each name.

Uses deprecated People Uris.
