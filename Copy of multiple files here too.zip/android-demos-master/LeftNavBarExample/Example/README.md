# Demo LeftNavBarExample/Example

Example show how to use the left navigation bar for TV.

It uses the example library from google tv, it uses deprecated ActionBar.Tab, no support classes are used.

