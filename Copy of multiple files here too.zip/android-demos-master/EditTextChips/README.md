# Demo EditTextChips

EditTextChips shows different libraries to display 'chips' in an EditText (usually used to show tags, email addresses, etc.).

The libraries demoed are:

 - [Chips library from EyeEm](https://github.com/eyeem/chips-android)
 - [Splitwise TokenAutoComplete](https://github.com/splitwise/TokenAutoComplete)
