# Demo GsonJsonWebservice

GsonJsonWebservice demonstrates how to make a request to twitter.

It uses Gson to handle json response.
