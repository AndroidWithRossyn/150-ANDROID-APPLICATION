package com.novoda.model;

import com.google.gson.annotations.SerializedName;

public class Metadata {
	
	@SerializedName("result_type")
	public String resultType;

}
