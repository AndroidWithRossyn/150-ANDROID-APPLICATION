# Change Log

Changes for each demo are documented in the corresponding change log files.

## June 2015
* Streamline package naming
* Add helper method for updating demos (maintainers use `apply from: 'gradle/update-demos.gradle'`)

## Jan 2015
* Gradleify all projects and upgrade to build tools 21.1.2
