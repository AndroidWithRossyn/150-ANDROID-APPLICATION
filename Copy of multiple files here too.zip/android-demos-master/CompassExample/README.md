# Demo CompassExample

Demonstrates use of the deprecated Novocation library. The app works only for pre-jellybean devices.

