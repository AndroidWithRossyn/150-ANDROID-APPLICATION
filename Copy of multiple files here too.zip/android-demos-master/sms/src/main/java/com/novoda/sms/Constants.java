package com.novoda.sms;

public class Constants {
	public static final String SENT = "SMS_SENT";
	public static final String DELIVERED = "SMS_DELIVERED";
}
