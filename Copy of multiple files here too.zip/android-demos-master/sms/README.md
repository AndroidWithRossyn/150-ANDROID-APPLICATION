# Demo sms

sms demonstrates how to send SMS using the `SmsManager`.

It uses the deprecated `gsm.SmsManager`.
