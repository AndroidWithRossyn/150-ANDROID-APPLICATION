package novoda.demo;

import android.app.Activity;
import android.os.Bundle;

public class ToThis extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_transition_to_this);
    }
}
