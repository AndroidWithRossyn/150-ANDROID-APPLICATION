# Demo CustomActivityTransition

CustomActivityTransition demonstrates how to define animations in the application theme.

The animations to use for opening and closing activities are defined in
[styles_master.xml](src/main/res/values/styles_master.xml). The animations themselves are defined in the
[anim folder](src/main/res/anim).

