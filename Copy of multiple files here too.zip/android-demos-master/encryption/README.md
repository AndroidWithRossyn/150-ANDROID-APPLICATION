# Demo encryption

Encyption demonstrates how to use javax.crypto in Activities.
