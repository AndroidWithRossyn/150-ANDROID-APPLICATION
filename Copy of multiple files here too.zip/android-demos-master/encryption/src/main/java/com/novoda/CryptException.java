package com.novoda;

public class CryptException extends Exception {
    CryptException(Throwable cause) {
        super(cause);
    }
}
