# Demo Livewallpaper/switch_leftright

switch_leftright demonstrates how to live wall papers with animations

Crashes on newer devices due to bitmap handling.
