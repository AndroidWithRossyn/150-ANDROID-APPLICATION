# Demo Livewallpaper/switch_animation

switch_animation demonstrates how to live wall papers with animations

Crashes on newer devices due to bitmap handling.

