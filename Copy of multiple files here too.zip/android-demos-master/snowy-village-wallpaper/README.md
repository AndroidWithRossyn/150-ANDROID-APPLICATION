Snowy Village Live Wallpaper
====================

![Icon](https://raw.githubusercontent.com/novoda/android-demos/master/snowy-village-wallpaper/app/src/main/res/drawable-xxhdpi/ic_launcher.png)

A festive snowy village live wallpaper.
 
Based on the [amazing design](https://www.novoda.com/blog/happy-holidays-from-novoda) from Qi Qu and Nick Howes'[Parallax live wallpaper](https://github.com/halfninja/android-parallax-wallpaper).

![Animated demo](https://raw.githubusercontent.com/novoda/android-demos/master/snowy-village-wallpaper/preview.gif)

<a href="https://play.google.com/store/apps/details?id=com.novoda.snowyvillagewallpaper&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1"><img alt="Get it on Google Play" width="25%" height="25%" src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" /></a>

<sub><sup>Android, Google Play and the Google Play logo are trademarks of Google Inc.</sub></sup>
