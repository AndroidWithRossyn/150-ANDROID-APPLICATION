package com.novoda.snowyvillagewallpaper.santa;

class Clock {

    public long getCurrentTime() {
        return System.currentTimeMillis();
    }

}
