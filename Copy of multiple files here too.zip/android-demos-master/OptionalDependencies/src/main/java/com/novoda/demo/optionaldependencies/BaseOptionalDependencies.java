package com.novoda.demo.optionaldependencies;

import android.widget.TextView;

public class BaseOptionalDependencies {
    public void updatePaidContent(TextView textView) {
        // no-op
    }
}
