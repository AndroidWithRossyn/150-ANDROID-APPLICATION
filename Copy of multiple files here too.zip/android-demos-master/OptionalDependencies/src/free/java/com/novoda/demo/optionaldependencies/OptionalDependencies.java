package com.novoda.demo.optionaldependencies;

public class OptionalDependencies extends BaseOptionalDependencies {
}
