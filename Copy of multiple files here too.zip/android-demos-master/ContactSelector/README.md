# Demo ContactSelector

ContactSelector demonstrates the use of the pick action for contacts.

It allows the user to select a contact and displays the primary name. This requires the READ_CONTACTS` permission.
