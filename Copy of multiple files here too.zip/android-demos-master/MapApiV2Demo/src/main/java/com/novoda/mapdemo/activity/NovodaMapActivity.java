package com.novoda.mapdemo.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import com.novoda.mapdemo.R;

public class NovodaMapActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.novoda_demo);
    }

}
