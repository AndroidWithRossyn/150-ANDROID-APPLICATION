MapApiV2Demo
============

Based upon the Google-Play-Services r3 maps example.

This project aims to show how simple it is to create a map and show your location on it.

To use this demo you will need to provide your own Maps API Key. This needs to be placed in the AndroidManifest.xml.
https://developers.google.com/maps/documentation/android/start#the_google_maps_api_key

The google-play-service has also been "mavenised" for ease of use,

enjoy!
