# Demo PinchZoomDetector

PinchZoomDetector demonstrates how to add pinch to zoom gesture to an activity.
