package com.novoda.demo.tddpersistence;


public interface TestBuilder<T> {

    T build();
}
