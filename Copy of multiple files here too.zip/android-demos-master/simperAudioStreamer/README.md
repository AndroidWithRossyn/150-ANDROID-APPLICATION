# Demo simperAudioStreamer

simperAudioStreamer demonstrates how to provide a simple audio stream service.

The API for the service provides play, stop, currentPosition.
