# Demo TabHostSelfContainedTabBrowsing

TabHostSelfContainedTabBrowsing demonstrates a simple use of `TabHost` class with navigation between tabs.
