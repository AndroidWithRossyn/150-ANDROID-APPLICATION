# Demo FixedSizeTextColumns

FixedSizeTextColumns shows how WebView behaves with different font sizes.

The user can choose from three different layouts and change the font size via menu.
