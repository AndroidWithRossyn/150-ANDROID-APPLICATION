# Demo wizard

wizard shows how to click through several activities in a wizzard like manner.

