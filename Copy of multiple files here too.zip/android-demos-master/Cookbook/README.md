Description
===========

A series of common coding recipes that will help you building great apps.

Android
-------

[Change the Device Locale for Instrumentation Tests ](change_device_locale_recipe.md)

[Create and add a Native Ad Express](add_native_express_adverts.md)