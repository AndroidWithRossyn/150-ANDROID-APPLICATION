# Demo CarouselFragment

The CarouselFragment demonstrates how to select content using the (deprecated) Gallery widget on TV.

The demo is only controlled by dpad keys or media buttons, press enter to select a content.

![Screenshot](screenshot.png)