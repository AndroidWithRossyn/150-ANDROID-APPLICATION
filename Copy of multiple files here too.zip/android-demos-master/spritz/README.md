<img src="images/spritz-header.png" />

Spritz is an Android library to seamlessly trigger a Lottie animation when the user drags a `ViewPager` or changes page programmatically.
It supports animating while swiping and auto-playing when the swipe is complete.

--------

[**Spritz has moved to the new novoda/spritz repo!**](https://github.com/novoda/spritz)
