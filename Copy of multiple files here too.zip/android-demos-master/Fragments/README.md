# Demo Fragments

Fragments demonstrates how to use activities and fragments for basic master/detail layout.

It does not use the support classes.
