package novoda.demo.fragments.list;

public final class Constants {
    public static final String[] ITEMS = 
    {
            "Item 1",   
            "Item 2",
            "Item 3",       
            "Item 4",
    };
    
    public static final String[] DETAILS = 
    {
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1," +
            "Item 1, Item 1, Item 1, Item 1, Item 1, Item 1,",
            
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2," +
            "Item 2, Item 2, Item 2, Item 2, Item 2, Item 2,",
            
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3," +
            "Item 3, Item 3, Item 3, Item 3, Item 3, Item 3,",
            
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4," +
            "Item 4, Item 4, Item 4, Item 4, Item 4, Item 4,"
    };
}
