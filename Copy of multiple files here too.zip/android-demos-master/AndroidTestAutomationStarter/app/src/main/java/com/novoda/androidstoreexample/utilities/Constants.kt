package com.novoda.androidstoreexample.utilities

const val CATEGORY_ID_EXTRA = "CATEGORY_ID"
const val PRODUCT_ID_EXTRA = "PRODUCT_ID"