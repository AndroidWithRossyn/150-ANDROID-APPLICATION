package com.novoda.androidstoreexample.mvp.presenter

interface BasketPresenter {

    fun loadBasket()
}