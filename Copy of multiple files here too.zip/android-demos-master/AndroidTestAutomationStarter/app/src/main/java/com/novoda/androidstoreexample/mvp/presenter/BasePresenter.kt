package com.novoda.androidstoreexample.mvp.presenter

interface BasePresenter {

    fun cancel()
}