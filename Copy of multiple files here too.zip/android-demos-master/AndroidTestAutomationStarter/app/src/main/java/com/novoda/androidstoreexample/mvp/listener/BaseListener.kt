package com.novoda.androidstoreexample.mvp.listener

interface BaseListener {

    fun onFailure(message: String)
}