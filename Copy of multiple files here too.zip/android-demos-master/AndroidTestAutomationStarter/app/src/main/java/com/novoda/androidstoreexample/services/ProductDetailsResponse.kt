package com.novoda.androidstoreexample.services

import com.novoda.androidstoreexample.models.Product

data class ProductDetailsResponse(val item: Product)