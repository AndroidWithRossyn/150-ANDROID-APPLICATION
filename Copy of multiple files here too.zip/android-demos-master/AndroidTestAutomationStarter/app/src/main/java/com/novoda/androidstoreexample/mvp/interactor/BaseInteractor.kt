package com.novoda.androidstoreexample.mvp.interactor

interface BaseInteractor {
    fun cancel()
}