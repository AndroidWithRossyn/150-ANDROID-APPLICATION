package com.eventyay.organizer.data.network;

public interface ConnectionStatus {

    boolean isConnected();

}
