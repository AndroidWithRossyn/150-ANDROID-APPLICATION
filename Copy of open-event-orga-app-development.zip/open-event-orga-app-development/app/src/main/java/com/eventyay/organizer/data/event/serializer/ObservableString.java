package com.eventyay.organizer.data.event.serializer;

import android.databinding.ObservableField;

public class ObservableString extends ObservableField<String> {

    public ObservableString() { }

    public ObservableString(String string) {
        super(string);
    }

}
