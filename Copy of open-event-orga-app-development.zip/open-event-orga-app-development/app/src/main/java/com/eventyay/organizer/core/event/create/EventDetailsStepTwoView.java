package com.eventyay.organizer.core.event.create;

public interface EventDetailsStepTwoView {
}
