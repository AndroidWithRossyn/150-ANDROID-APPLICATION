package com.eventyay.organizer.common;

public interface Pipe<T> {

    void push(T item);

}
