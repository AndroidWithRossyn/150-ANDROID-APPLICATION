package com.eventyay.organizer.common.mvp.view;

public interface Erroneous {

    void showError(String error);

}
