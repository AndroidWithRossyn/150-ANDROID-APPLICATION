package com.eventyay.organizer.core.settings.autocheckin;

import com.eventyay.organizer.common.mvp.view.Erroneous;
import com.eventyay.organizer.common.mvp.view.Progressive;

public interface AutoCheckInView extends Progressive, Erroneous {
}
