package com.eventyay.organizer.common.mvp.view;

public interface Progressive {

    void showProgress(boolean show);

}
