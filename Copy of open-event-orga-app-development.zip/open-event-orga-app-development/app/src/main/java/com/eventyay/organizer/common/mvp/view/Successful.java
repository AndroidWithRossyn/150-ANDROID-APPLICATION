package com.eventyay.organizer.common.mvp.view;

public interface Successful {

    void onSuccess(String message);

}
