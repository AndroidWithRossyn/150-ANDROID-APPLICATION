package com.eventyay.organizer.common.model;

public interface HeaderProvider {
    String getHeader();

    long getHeaderId();
}
