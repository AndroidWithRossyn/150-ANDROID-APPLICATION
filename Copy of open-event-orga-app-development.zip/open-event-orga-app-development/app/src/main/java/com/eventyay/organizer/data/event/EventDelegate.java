package com.eventyay.organizer.data.event;

import com.eventyay.organizer.common.model.HeaderProvider;

public interface EventDelegate extends Comparable<Event>, HeaderProvider {

}
