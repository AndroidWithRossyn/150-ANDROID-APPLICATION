package com.eventyay.organizer.data.order.model;

public class OrderReceiptResponse {

    public String message;
    public String error;
}
