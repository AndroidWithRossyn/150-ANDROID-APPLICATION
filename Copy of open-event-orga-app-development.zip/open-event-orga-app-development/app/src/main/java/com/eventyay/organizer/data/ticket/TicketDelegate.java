package com.eventyay.organizer.data.ticket;

public interface TicketDelegate extends Comparable<Ticket> { }
