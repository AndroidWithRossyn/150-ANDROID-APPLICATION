package com.eventyay.organizer.common.mvp.view;

public interface Refreshable {

    void onRefreshComplete(boolean success);

}
