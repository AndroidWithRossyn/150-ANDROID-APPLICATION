package com.eventyay.organizer.common.mvp.presenter;

public interface BasePresenter {

    void start();

    void detach();

}
