package com.eventyay.organizer.common.mvp.view;

public interface ItemResult<T> {

    void showResult(T item);

}
