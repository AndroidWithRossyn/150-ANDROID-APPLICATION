package com.eventyay.organizer.common.di;

/**
 * Marks an activity / fragment injectable.
 */
public interface Injectable {
}
