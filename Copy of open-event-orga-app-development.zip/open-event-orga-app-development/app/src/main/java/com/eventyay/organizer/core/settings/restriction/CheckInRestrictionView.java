package com.eventyay.organizer.core.settings.restriction;

import com.eventyay.organizer.common.mvp.view.Erroneous;
import com.eventyay.organizer.common.mvp.view.Progressive;

public interface CheckInRestrictionView extends Progressive, Erroneous {
}
