package com.eventyay.organizer.core.settings;

import android.content.Context;

class AcknowledgementDecider {

    public boolean shouldShowAcknowledgement() {
        return false;
    }

    public void openAcknowledgementsSection(Context context) {
        //do nothing
    }
}
