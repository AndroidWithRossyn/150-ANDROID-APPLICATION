package com.eventyay.organizer.common.di.module.android;

import dagger.Module;

@Module
public abstract class FlavorModule {
}
