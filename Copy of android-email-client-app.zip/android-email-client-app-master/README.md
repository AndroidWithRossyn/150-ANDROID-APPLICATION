# android-email-client-app
New style Email Client App for android
