# android-tip-calculator
Deitel Android Tip Calculator

A simple tip calculator practicing with GridLayout and some update code to update information based on EditText and slider value to calculate 15% and custom percent tips.
