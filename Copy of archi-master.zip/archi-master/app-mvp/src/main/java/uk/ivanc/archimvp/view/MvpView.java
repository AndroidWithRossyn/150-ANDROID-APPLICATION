package uk.ivanc.archimvp.view;

import android.content.Context;

public interface MvpView {

    Context getContext();
}
