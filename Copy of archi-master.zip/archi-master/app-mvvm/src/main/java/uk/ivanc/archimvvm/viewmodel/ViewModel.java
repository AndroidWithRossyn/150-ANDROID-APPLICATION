package uk.ivanc.archimvvm.viewmodel;

/**
 * Interface that every ViewModel must implement
 */
public interface ViewModel {

    void destroy();
}
