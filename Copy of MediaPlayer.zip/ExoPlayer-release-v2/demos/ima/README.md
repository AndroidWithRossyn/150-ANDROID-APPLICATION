# IMA demo application #

This folder contains a demo application that showcases ExoPlayer integration
with the IMA SDK.
