package com.mindorks.framework.mvp.ui.base.view

/**
 * Created by jyotidubey on 15/01/18.
 */
interface DialogMVPView : MVPView