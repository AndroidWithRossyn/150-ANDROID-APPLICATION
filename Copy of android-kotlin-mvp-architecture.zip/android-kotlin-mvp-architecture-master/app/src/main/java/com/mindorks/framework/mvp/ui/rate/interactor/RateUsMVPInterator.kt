package com.mindorks.framework.mvp.ui.rate.interactor

import com.mindorks.framework.mvp.ui.base.interactor.MVPInteractor

/**
 * Created by jyotidubey on 15/01/18.
 */
interface RateUsMVPInterator : MVPInteractor{

    fun submitRating()
}