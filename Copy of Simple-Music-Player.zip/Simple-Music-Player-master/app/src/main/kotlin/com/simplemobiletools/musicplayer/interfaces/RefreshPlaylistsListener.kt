package com.simplemobiletools.musicplayer.interfaces

interface RefreshPlaylistsListener {
    fun refreshItems()
}
