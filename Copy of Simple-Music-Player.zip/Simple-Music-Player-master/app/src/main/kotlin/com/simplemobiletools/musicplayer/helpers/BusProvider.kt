package com.simplemobiletools.musicplayer.helpers

import com.squareup.otto.Bus

class BusProvider {
    companion object {
        val instance = Bus()
    }
}
