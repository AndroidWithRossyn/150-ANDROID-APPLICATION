package com.esoxjem.movieguide.listing.sorting;

/**
 * @author arun
 */
public interface SortingDialogInteractor
{
    int getSelectedSortingOption();

    void setSortingOption(SortType sortType);
}
