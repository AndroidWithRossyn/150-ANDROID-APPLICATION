package com.esoxjem.movieguide.details;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import javax.inject.Scope;


/**
 * @author arunsasidharan
 */
@Scope
@Retention(RetentionPolicy.RUNTIME)
public @interface DetailsScope
{
}
