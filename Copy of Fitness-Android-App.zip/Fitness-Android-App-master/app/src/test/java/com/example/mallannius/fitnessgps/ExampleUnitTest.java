package com.example.mallannius.fitnessgps;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * To work on unit tests, switch the showMap Artifact in the Build Variants view.
 */
public class ExampleUnitTest {
    @showMap
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }
}