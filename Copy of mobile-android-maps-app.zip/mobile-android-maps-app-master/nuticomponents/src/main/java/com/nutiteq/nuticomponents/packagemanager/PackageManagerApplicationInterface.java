package com.nutiteq.nuticomponents.packagemanager;

public interface PackageManagerApplicationInterface {

	public PackageManagerComponent getPackageManagerComponent();

	public Class getMainActivityClass();
}
