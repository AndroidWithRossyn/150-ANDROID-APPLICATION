package com.nutiteq.nuticomponents.packagemanager;

public class StackObject {
	public String name;
	public int position;

	public StackObject(String name, int position) {
		this.name = name;
		this.position = position;
	}
}
