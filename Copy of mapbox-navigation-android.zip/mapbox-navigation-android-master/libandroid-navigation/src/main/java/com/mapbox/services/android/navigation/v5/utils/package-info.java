/**
 * This contains common static util methods used throughout the Mapbox Navigation SDK.
 */
package com.mapbox.services.android.navigation.v5.utils;