/**
 * This contains a runtime exception to be thrown during the normal operation and does not need to
 * be declared in a method or constructor.
 */
package com.mapbox.services.android.navigation.v5.exception;