/**
 * Holds logic specific to detecting if a user goes off-route and invokes the
 * {@link com.mapbox.services.android.navigation.v5.offroute.OffRouteListener} when the logic
 * evaluates to true.
 */
package com.mapbox.services.android.navigation.v5.offroute;