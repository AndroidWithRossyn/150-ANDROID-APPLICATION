/**
 * Package containing the core navigation logic which monitors location updates and delegates task
 * accordingly.
 */
package com.mapbox.services.android.navigation.v5.navigation;