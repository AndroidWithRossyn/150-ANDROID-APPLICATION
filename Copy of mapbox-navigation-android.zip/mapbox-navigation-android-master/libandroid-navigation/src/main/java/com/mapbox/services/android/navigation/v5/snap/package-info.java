/**
 * Contains user location manipulation logic to cause it to snap to a biased location.
 */
package com.mapbox.services.android.navigation.v5.snap;