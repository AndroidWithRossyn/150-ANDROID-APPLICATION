package com.mapbox.services.android.navigation.v5.utils.span;

public interface SpanItem {

  Object getSpan();
}
