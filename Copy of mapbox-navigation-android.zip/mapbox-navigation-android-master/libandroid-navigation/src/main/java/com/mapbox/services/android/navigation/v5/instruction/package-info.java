/**
 * Contains instruction logic for providing turn by turn navigation instructions.
 */
package com.mapbox.services.android.navigation.v5.instruction;