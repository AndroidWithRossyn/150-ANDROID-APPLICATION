/**
 * Immutable model class which provides the users current progress along the route such as distance
 * or duration.
 */
package com.mapbox.services.android.navigation.v5.routeprogress;