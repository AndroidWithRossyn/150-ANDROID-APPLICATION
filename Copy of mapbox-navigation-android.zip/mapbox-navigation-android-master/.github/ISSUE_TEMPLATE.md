<!--
Hello and thanks for contributing! To help us diagnose your problem quickly, please:

 - Include a minimal demonstration of the bug, including code, logs, and screenshots.
 - Ensure you can reproduce the bug using the latest release.
 - Only post to report a bug or request a feature; direct all other questions to: https://stackoverflow.com/questions/tagged/mapbox
-->

**Android API:**
**Mapbox Navigation SDK version:**

### Steps to trigger behavior

 1.
 2.
 3.

### Expected behavior

### Actual behavior
