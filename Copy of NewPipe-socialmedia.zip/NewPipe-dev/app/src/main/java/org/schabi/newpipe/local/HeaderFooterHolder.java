package org.schabi.newpipe.local;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class HeaderFooterHolder extends RecyclerView.ViewHolder {
    public View view;

    public HeaderFooterHolder(View v) {
        super(v);
        view = v;
    }
}