package com.byoutline.kickmaterial.adapters;

/**
 * @author Pawel Karczewski <pawel.karczewski at byoutline.com> on 2015-01-25
 */
public interface RewardClickListener {

    void rewardClicked(int position);
}
