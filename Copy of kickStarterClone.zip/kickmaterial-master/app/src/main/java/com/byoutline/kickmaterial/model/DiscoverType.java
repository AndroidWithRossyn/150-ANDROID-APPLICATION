package com.byoutline.kickmaterial.model;

/**
 * @author Sebastian Kacprzak <sebastian.kacprzak at byoutline.com>
 */
public enum DiscoverType {
    DISCOVER, DISCOVER_MORE, DISCOVER_CATEGORY, SEARCH
}
