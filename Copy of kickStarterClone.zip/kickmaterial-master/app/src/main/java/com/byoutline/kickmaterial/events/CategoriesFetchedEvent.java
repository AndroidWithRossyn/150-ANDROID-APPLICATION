package com.byoutline.kickmaterial.events;

import com.byoutline.eventcallback.ResponseEventImpl;
import com.byoutline.kickmaterial.model.Category;

import java.util.List;

/**
 * Created by Sebastian Kacprzak on 24.03.15.
 */
public class CategoriesFetchedEvent extends ResponseEventImpl<List<Category>> {
}
