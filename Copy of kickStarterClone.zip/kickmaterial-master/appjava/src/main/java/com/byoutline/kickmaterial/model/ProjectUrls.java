package com.byoutline.kickmaterial.model;

import org.parceler.Parcel;

/**
 * Created by Sebastian Kacprzak on 24.03.15.
 */
@Parcel(Parcel.Serialization.FIELD)
public class ProjectUrls {
    public ProjectUrlsApi api;
    public WebUrlsApi web;

}
