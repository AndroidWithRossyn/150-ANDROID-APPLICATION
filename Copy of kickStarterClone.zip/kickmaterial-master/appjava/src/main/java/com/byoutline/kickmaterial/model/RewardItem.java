package com.byoutline.kickmaterial.model;

/**
 * @author Pawel Karczewski <pawel.karczewski at byoutline.com> on 2015-03-30
 */
public interface RewardItem {
    int ITEM = 0;
    int HEADER = 1;

    int getItemType();
}
