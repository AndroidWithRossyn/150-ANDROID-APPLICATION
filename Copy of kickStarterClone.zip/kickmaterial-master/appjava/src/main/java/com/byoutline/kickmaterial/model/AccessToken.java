package com.byoutline.kickmaterial.model;

/**
 * Created by Sebastian Kacprzak <sebastian.kacprzak at byoutline.com> on 31.03.15.
 */
public class AccessToken {
    public String accessToken;
    // user data;
}
