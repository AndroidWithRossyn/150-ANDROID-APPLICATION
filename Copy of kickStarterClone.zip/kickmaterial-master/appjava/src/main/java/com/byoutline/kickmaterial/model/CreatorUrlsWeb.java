package com.byoutline.kickmaterial.model;

import org.parceler.Parcel;

/**
 * @author Sebastian Kacprzak <sebastian.kacprzak at byoutline.com>
 */
@Parcel(Parcel.Serialization.FIELD)
public class CreatorUrlsWeb {
    public String user;
}
