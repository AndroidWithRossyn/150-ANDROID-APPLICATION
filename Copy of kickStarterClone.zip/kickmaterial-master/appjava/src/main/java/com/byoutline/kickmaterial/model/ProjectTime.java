package com.byoutline.kickmaterial.model;

/**
 * Created by Sebastian Kacprzak on 25.03.15.
 */
public class ProjectTime {
    public final String value;
    public final String description;

    public ProjectTime(String value, String description) {
        this.value = value;
        this.description = description;
    }
}
