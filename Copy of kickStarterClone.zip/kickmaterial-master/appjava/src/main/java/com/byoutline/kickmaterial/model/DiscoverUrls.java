package com.byoutline.kickmaterial.model;

/**
 * Created by Sebastian Kacprzak on 24.03.15.
 */
public class DiscoverUrls {
    public DiscoverUrlsApi api;
}
