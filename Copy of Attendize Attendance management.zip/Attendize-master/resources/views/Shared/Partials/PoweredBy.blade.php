{{--Attendize is provided free of charge on the condition the below hyperlink is left in place.--}}
{{--See https://www.attendize.com/licence.html for more information.--}}
Powered By <a style="color: #FFF;" title="Attendize - Sell Tickets Online" href="http://www.attendize.com/?powered_by">Attendize</a>
