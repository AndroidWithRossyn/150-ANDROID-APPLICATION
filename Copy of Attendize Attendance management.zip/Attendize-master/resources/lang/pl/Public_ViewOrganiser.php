<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/16 08:41:39 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
  'information' => 'Szczegóły',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
  'tickets' => 'Bilety',
  //==================================== Translations ====================================//
  'no_events' => 'W kategorii ":panel_title" nie ma dostępnych wydarzeń.',
  'organiser_dashboard' => 'Panel sterowania organizatora',
  'past_events' => 'Przeszłe wydarzenia',
  'upcoming_events' => 'Nadchodzące wydarzenia',
);