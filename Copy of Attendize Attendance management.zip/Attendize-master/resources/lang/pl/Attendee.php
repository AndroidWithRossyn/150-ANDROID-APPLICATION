<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:07:35 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'scan_another_ticket' => 'Zeskanuj kolejny bilet',
  'scanning' => 'Skanuję',
  //==================================== Translations ====================================//
  'attendees' => 'Uczestnicy',
  'check_in' => 'Lista gości: :event',
  'email' => 'Email',
  'email_address' => 'Adres Email',
  'event_attendees' => 'Uczestnicy Wydarzenia',
  'first_name' => 'Imię',
  'last_name' => 'Nazwisko',
  'name' => 'Imię i Nazwisko',
  'search_attendees' => 'Przeszukaj dane uczestników...',
  'send_invitation_n_ticket_to_attendee' => 'Wyślij zaproszenie i bilet do uczestnika.',
);