<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/23 14:17:14 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\OrganiserSocialSection.blade.php
  'pinterest' => 'Pinterest',
  //==================================== Translations ====================================//
  'email' => 'Email',
  'facebook' => 'Facebook',
  'g+' => 'Google+',
  'linkedin' => 'LinkedIn',
  'share_buttons_to_show' => 'Przyciski Udostępniania do Wyświetlenia',
  'social_settings' => 'Ustawienia Społeczności',
  'social_share_text' => 'Tekst Udostępnienia',
  'social_share_text_help' => 'To jest tekst, który zostanie dodany do wiadomości w trakcie udostępniania wydarzenia.',
  'twitter' => 'Twitter',
  'whatsapp' => 'WhatsApp',
);