<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:21:50 
*************************************************************************/

return array (
    //============================== New strings to translate ==============================//
    'event_page_preview' => 'Podgląd strony wydarzenia',
    //==================================== Translations ====================================//
    'background_options' => 'Opcje tła',
    'images_provided_by_pixabay' => 'Obrazy dostarczone przez <b>PixaBay.com</b>',
    'select_from_available_images' => 'Skorzystaj z dostępnych obrazów',
    'use_a_colour_for_the_background' => 'Skorzystaj z koloru jako tła',
);