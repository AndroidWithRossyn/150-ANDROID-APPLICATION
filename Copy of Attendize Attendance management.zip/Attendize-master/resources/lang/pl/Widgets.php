<?php

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Widgets.blade.php
  'embed_preview' => 'Podgląd Wklejki',
  //==================================== Translations ====================================//
  'event_widgets' => 'Widgety Wydarzenia',
  'html_embed_code' => 'Kod HTML Do Wklejenia',
  'instructions' => 'Instrukcje',
  'instructions_text' => 'Po prostu skopiuj poniższy kod HTML na swoją stronę internetową, aby wyświetlić widget.',
);