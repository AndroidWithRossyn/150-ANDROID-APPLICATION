<?php

return [
    'back_soon' => 'We\'ll be back soon',
    'back_soon_description'     => 'We\'re currently making improvements to our website.',

];
