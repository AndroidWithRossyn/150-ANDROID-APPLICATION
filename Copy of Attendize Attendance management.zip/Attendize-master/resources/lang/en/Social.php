<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/23 14:17:14 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\OrganiserSocialSection.blade.php
  'pinterest' => 'Pinterest',
  //==================================== Translations ====================================//
  'email' => 'Email',
  'facebook' => 'Facebook',
  'g+' => 'Google+',
  'linkedin' => 'LinkedIn',
  'share_buttons_to_show' => 'Share Buttons To Show',
  'social_settings' => 'Social Settings',
  'social_share_text' => 'Social Share Text',
  'social_share_text_help' => 'This is the text which will be share by default when a user shares your event on social networks',
  'twitter' => 'Twitter',
  'whatsapp' => 'WhatsApp',
);