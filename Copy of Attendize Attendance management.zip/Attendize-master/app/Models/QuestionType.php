<?php

namespace App\Models;

class QuestionType extends \Illuminate\Database\Eloquent\Model
{
    //put your code here
}
