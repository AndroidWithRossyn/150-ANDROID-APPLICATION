<?php

namespace App\Models;

    /*
      Attendize.com   - Event Management & Ticketing
     */

/**
 * Description of DiscountCode.
 *
 * @author Dave
 */
class DiscountCode extends \Illuminate\Database\Eloquent\Model
{
    //put your code here
}
