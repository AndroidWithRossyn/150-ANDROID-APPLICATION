<?php

/*
  Attendize.com   - Event Management & Ticketing
 */

/**
 * Description of UserMailer.
 *
 * @author Dave
 */
class UserMailer
{
    //put your code here
}
