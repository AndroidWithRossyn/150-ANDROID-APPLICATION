package com.anysoftkeyboard.dictionaries;

public interface AutoText {
    String lookup(CharSequence word);
}
