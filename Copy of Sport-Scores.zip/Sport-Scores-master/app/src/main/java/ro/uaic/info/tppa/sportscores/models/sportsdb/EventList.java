package ro.uaic.info.tppa.sportscores.models.sportsdb;

import java.util.List;

public class EventList {
    List<Event> events;

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }
}
