package ro.uaic.info.tppa.sportscores.models.sportsdb;

import java.util.List;

public class TableList {
    List<TableListItem> table;

    public List<TableListItem> getTable() {
        return table;
    }

    public void setTable(List<TableListItem> table) {
        this.table = table;
    }
}
