# PinkMoon
A tinder like android dating app which runs in the android platforms avaiable for android version 4.0 or up.

## Demo Screenshots

### main page
<img width="263" alt="img1" src="https://user-images.githubusercontent.com/19808690/41212921-6bb685ce-6cf6-11e8-96bb-2de0fd5d43bb.png">

### like or dislike
<img width="265" alt="img2" src="https://user-images.githubusercontent.com/19808690/41212929-7d233b72-6cf6-11e8-9cde-0fac96636a9f.png">
<img width="260" alt="img3" src="https://user-images.githubusercontent.com/19808690/41212931-8574a5f4-6cf6-11e8-8ce8-f9ff59b4cdaa.png">

## How to use
- Register an account, and select the gender you are interested, age, and interests
- Email verify your account, and log in
- In the main page, swipe (or click) the profile image of others. If you like the person, swipe right (click right), if don't, swipe left (or click left)
- If both of you like each other, you can see the secured info of that person, and send either email or SMS to her/him
- Real time video chat with that person (TBD)

## License
Copyright 2018 Spring COEN268_SCU_Project team 6:
- Yuxuan Li
- Vikas Radhakrishna Shetty
- Xiaoyu Huang
- Jing Chen