package client.yalantis.com.githubclient.model

/**
 * Created by Alexey on 07.10.2016.
 */
data class Owner(val login: String, val avatar_url: String)