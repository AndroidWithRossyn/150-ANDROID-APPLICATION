package client.yalantis.com.githubclient.model

/**
 * Created by Alexey on 07.10.2016.
 */
data class Source(val id: Long, val owner: Owner)