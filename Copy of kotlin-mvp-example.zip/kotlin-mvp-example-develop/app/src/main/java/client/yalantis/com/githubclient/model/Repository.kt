package client.yalantis.com.githubclient.model

/**
 * Created by andrewkhristyan on 10/2/16.
 */
data class Repository(val id: Long, val name: String, val description: String)