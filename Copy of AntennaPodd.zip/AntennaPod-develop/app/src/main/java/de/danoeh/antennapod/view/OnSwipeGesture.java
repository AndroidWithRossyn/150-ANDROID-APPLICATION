package de.danoeh.antennapod.view;

public interface OnSwipeGesture {

    boolean onSwipeLeftToRight();

    boolean onSwipeRightToLeft();

}
