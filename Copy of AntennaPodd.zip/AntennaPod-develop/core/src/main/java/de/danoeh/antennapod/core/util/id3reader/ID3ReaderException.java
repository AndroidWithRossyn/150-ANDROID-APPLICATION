package de.danoeh.antennapod.core.util.id3reader;

public class ID3ReaderException extends Exception {

	public ID3ReaderException() {
	}

	public ID3ReaderException(String arg0) {
		super(arg0);
	}

	public ID3ReaderException(Throwable arg0) {
		super(arg0);
	}

	public ID3ReaderException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
