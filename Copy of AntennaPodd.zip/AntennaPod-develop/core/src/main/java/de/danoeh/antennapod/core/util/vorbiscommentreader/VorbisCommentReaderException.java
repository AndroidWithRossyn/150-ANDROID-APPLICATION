package de.danoeh.antennapod.core.util.vorbiscommentreader;
public class VorbisCommentReaderException extends Exception {

	public VorbisCommentReaderException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VorbisCommentReaderException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public VorbisCommentReaderException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public VorbisCommentReaderException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
