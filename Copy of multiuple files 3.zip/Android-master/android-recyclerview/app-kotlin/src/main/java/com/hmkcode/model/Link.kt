package com.hmkcode.model

class Link {

    var icon: Int = 0
    var title: String? = null
    var url: String? = null
}
