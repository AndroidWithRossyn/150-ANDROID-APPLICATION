# Android MultiService OAuth Demo

Demo using [RestClientTemplate](https://github.com/thecodepath/RestClientTemplate) to 
connect to multiple different services in the same activity.

![First Screen](http://i.imgur.com/yiBIhIJ.png)
