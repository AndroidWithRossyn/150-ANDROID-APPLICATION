package org.bookdash.android.data.tutorial;

import java.util.ArrayList;

import za.co.riggaroo.materialhelptutorial.TutorialItem;



public interface TutorialsRepository {
    ArrayList<TutorialItem> getTutorialItems();
}
