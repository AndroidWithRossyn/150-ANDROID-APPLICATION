package org.bookdash.android.presentation.base;

public interface MvpView {
}
