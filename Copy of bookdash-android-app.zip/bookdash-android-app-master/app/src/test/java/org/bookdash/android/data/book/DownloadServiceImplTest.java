package org.bookdash.android.data.book;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;


public class DownloadServiceImplTest {

    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void testDownloadFile() throws Exception {

    }

    @Test
    public void testDeleteDownload() throws Exception {

    }
}