package com.github.premnirmal.ticker.components

import android.content.Context

/**
 * Created by premnirmal on 2/28/16.
 */
internal class AnalyticsImpl(context: Context) : Analytics