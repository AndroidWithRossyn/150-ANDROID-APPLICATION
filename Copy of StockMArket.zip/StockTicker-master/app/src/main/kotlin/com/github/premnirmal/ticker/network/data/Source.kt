package com.github.premnirmal.ticker.network.data

data class Source(var name: String? = null, var id: String? = null)