package com.github.premnirmal.ticker.events

data class ErrorEvent(val message: String)