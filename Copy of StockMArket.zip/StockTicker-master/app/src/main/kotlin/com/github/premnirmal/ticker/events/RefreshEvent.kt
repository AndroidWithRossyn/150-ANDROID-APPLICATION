package com.github.premnirmal.ticker.events

/**
 * Created by premnirmal on 4/20/17.
 */
class RefreshEvent