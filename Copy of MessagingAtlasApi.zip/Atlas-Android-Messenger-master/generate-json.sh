echo '{
        "project_info": {
          "project_number": "dumdumdum-something",
          "project_id": "dee-doo-dah-32"
        },
        "client": [
          {
            "client_info": {
              "mobilesdk_app_id": "yeedleoooh:uh:uh",
              "android_client_info": {
                "package_name": "com.layer.messenger"
              }
            },
            "oauth_client": [

            ],
            "api_key": [
              {
                "current_key": "laaaadeeeeedaaahhhdada"
              }
            ],
            "services": {
              "analytics_service": {
                "status": 1
              },
              "appinvite_service": {
                "status": 1,
                "other_platform_oauth_client": [

                ]
              },
              "ads_service": {
                "status": 1
              }
            }
          },
          {
            "client_info": {
              "mobilesdk_app_id": "1:yodlee:oooo:ohoh",
              "android_client_info": {
                "package_name": "com.layer.sdkquickstart"
              }
            },
            "oauth_client": [

            ],
            "api_key": [
              {
                "current_key": "llaaaaaa-deeee-doooo-dahdah"
              }
            ],
            "services": {
              "analytics_service": {
                "status": 1
              },
              "appinvite_service": {
                "status": 1,
                "other_platform_oauth_client": [

                ]
              },
              "ads_service": {
                "status": 1
              }
            }
          }
        ],
        "configuration_version": "1"
      }' > ./app/google-services.json