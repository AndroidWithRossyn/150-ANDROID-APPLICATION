## LifeStyle  
### \#   
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### A  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### B  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Banya](https://github.com/forezp/banya) | An openresource  for Douban API with NetEase Music UI. | Java |

### C  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### D  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### E  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Easy Diary](https://github.com/hanjoongcho/aaf-easydiary) | This is a diary application optimized to user experience. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=me.blog.korn123.easydiary)

### F  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### G  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### H  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### I  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### J  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### K  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### L  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### M  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Memento Namedays](https://github.com/alexstyl/Memento-Namedays) | The sweetest Namedays calendar for Android. | Java |[![Get it on Google Play](http://developer.android.com/images/brand/en_app_rgb_wo_60.png)](https://play.google.com/store/apps/details?id=com.alexstyl.specialdates) 

### N  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Narrate](https://github.com/timothymiko/narrate-android) | A small and simple journal. | Java |[![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.datonicgroup.narrate.app) 

### O  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | |  

### P  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### Q  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### R  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### S  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### T  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### U  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### V  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 
 
### W  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Wake You In Music](https://github.com/CedrickFlocon/wakeyouinmusic) | Alarm for Spotify or Deezer user. | Java |[![Get it on Google Play](http://developer.android.com/images/brand/en_app_rgb_wo_60.png)](https://play.google.com/store/apps/details?id=org.neige.wakeyouinmusic.android)

### X  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### Y  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### Z  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 
 
