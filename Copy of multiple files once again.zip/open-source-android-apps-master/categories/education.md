## Education  
### \#   
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### A  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[AnkiDroid](https://github.com/ankidroid/Anki-Android) | A semi-official port of the open source [Anki](http://ankisrs.net) spaced repetition flashcard system to Android. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.ichi2.anki)
[Awesome-Campus](https://github.com/MummyDing/Awesome-Campus) | Jiangxi Normal University Android App |Java | [![Get it on Third-Party](http://i.imgur.com/ppYJYe5.png)](http://fir.im/AwesomeCampus)

### B  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### C  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### D  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### E  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### F  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### G  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[GivesMeHope](https://github.com/jparkie/GivesMeHopeAndroidClient) | An unofficial Gives Me Hope Android client for educational purposes. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.jparkie.givesmehope)

### H  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Hubble Gallery](https://github.com/derekcsm/hubble_gallery) | View, Save, and Read about Hubble's best images. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.derek_s.hubble_gallery)
[Hillffair](https://github.com/appteam-nith/Hillffair) | Hillffair is an open source college app made for Cultural fest known as Hillffair of NIT Hamirpur, India by [App Team NITH](https://github.com/appteam-nith). This app contains some additional features like online quiz as well as newsfeed along with features like notifications. | Java | [Get it on Google Play](https://play.google.com/store/apps/details?id=appteam.nith.hillffair)

### I  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[IELTS Vocabulary Flashcards](https://github.com/bychkovdmitrii/words) | Flashcards for IELTS exam. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.dbychkov.words) 

### J  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### K  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### L  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[LeeCo](https://github.com/Nightonke/LeeCo) | LeeCo is an awesome app for algorithem problems(including unlock), solutions, discuss(from leetcode) and comments. | Java | [Get it on Github](https://github.com/Nightonke/LeeCo/blob/master/APK/LeeCo%20V1.0.0.apk) 

### M  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### N  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------:  
[NSIT Connect](https://github.com/Swati4star/NSIT-Connect) | The official NSITonline app that aims to act as a companion app for NSIT students  | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=nsit.app.com.nsitapp)  
[festnimbus](https://github.com/appteam-nith/festnimbus) | Festnimbus is an open source college app made for Technical fest known as Nimbus of NIT Hamirpur, India by [App Team NITH](https://github.com/appteam-nith) | Java | [Get it on Google Play](https://play.google.com/store/apps/details?id=com.appteam.nimbus)  

### O  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### P  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### Q  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### R  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### S  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------:  
[Sahayak](https://github.com/Neophytes/microsoft-pragyan-hackathon) |An android app aimed to make a fun-filled educational tool for naives. Aimed at rural children and adults |Java |
[Seashell-app](https://github.com/drakeet/Seashell-app) | 贝壳单词 APP Android 客户端 | Java |   
[Stepic](https://github.com/StepicOrg/stepic-android) | Free online courses with certificates | Java+Kotlin | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.stepic.droid)  

### T  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### U  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Unisannio](https://github.com/alter-ego/unisannio-reboot/) | Android app for University of Sannio students | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=solutions.alterego.android.unisannio)   

### V  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### W  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[WaniKani for Android](https://github.com/xiprox/WaniKani-for-Android) | An Android client application for the awesome kanji learning website wanikani.com | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=tr.xip.wanikani)

### X  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### Y  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### Z  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 
