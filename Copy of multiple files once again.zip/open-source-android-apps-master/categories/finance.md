## Finance  
### \#   
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### A  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### B  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Bither](https://github.com/bither/bither-android) | Simple and secure Bitcoin wallet. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=net.bither)   
[bitcoin-wallet](https://github.com/schildbach/bitcoin-wallet) | Bitcoin Wallet app for your Android device. Standalone Bitcoin node, no centralized backend required. http://wallet.schildbach.de | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=de.schildbach.wallet)

### C  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[CoCoin](https://github.com/Nightonke/CoCoin) | Multi-view Accounting Application. | Java |[![Get it on Third-Party](http://i.imgur.com/ppYJYe5.png)](https://github.com/Nightonke/CoCoin/tree/master/APK)
[Coins](https://github.com/nothingmagical/coins-android) | A simple app to see how much your Bitcoins are worth. | Java |
[Currency Converter](https://github.com/samanyougarg/Currency-Converter-Android) | A simple and easy-to-use material design currency converter for android. | Java |[![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.appisode.currencyconverter) 
### D  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### E  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### F  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Financius](https://github.com/mvarnagiris/financius-public) | Financius is a simple application that helps you log and track your expenses and keep an eye on your balance. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.code44.finance)

### G  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[GnuCash](https://github.com/codinguser/gnucash-android) | Gnucash for Android mobile companion application. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.gnucash.android)   

### H  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### I  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### J  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### K  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### L  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### M  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Money Manager Ex](https://github.com/moneymanagerex/android-money-manager-ex) | Android port of Money Manager Ex. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.money.manager.ex)   

### N  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### O  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### P  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### Q  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### R  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### S  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### T  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 

### U  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### V  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### W  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### X  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### Y  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### Z  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 
 
