## Health & Fitness  
### \#   
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### A  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Android heart rate monitor](https://github.com/phishman3579/android-heart-rate-monitor) | Android based heart rate monitor which uses the camera and its flash to determine the users heart rate in beats per minute. | Java | |
[Android app to collect medical data](https://github.com/Ana06/medical-data-android) | Android app to collect data to be analyzed for medical purposes. | Java | |

### B  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### C  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### D  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### E  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### F  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### G  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### H  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### I  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### J  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### K  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### L  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
| | | 

### M  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### N  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[NightSight](https://github.com/meghalagrawal/NightSight) |An App that Decreases your Phone's brightness below system's lowest level.| | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=meghal.developer.nightsight.project) 

### O  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | |

### P  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Pedometer](https://github.com/j4velin/Pedometer) | Lightweight pedometer app for Android using the hardware step sensor | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=de.j4velin.pedometer)   

### Q  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### R  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[RunnerUp](https://github.com/jonasoreland/runnerup) | An open source run tracker inspired by Garmin 410, RunKeeper and EveryWhere Run. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.runnerup)

### S  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### T  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### U  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### V  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### W  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### X  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 
 
### Y  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### Z  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 
 
