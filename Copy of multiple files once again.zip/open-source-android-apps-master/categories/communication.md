## Communication  
### \#   
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### A  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### B  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### C  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[ChatSecureAndroid](https://github.com/guardianproject/ChatSecureAndroid) | the most private messaging for Android and iOS | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=info.guardianproject.otr.app.im) 

### D  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### E  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### F  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### G  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### H  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### I  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[IRCCloud](https://github.com/irccloud/android) | The official Android app for IRCCloud.com | Java | [![Get it On Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.irccloud.android)

### J  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### K  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[K-9 Mail](https://github.com/k9mail/k-9) | K-9 Mail – Advanced Email for Android | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.fsck.k9) 
[KissProxy](https://github.com/coderkiss/KissProxy) | NIO based android http&https local proxy. | Java |   
[Kontalk Messenger](https://github.com/kontalk/androidclient) | Kontalk official Android client http://www.kontalk.org | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.kontalk) 
[KouChat](https://github.com/blurpy/kouchat-android) | Serverless LAN chat application. http://www.kouchat.net/ | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=net.usikkert.kouchat.android) 

### L  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### M  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[MaterialQQLite](https://github.com/wang4yu6peng13/MaterialQQLite) | A material style of QQ (based on MingQQ) | Java |  
[messaging](https://github.com/Odoo-mobile/messaging) | Odoo Mobile Messaging Client. | Java |  
[mogujie TeamTalk](https://github.com/mogutt/TTAndroidClient) | The android client of mogutt http://tt.mogu.io/ | Java | 

### N  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### O  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### P  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[ProxyDroid](https://github.com/madeye/proxydroid) | Global Proxy for Android  | C | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.proxydroid)   

### Q  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[qksms](https://github.com/qklabs/qksms) | QKSMS is an open source replacement to the stock messaging app on Android  | java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.moez.QKSMS)   

### R  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Rocket.Chat](https://github.com/RocketChat/Rocket.Chat) | Have your own Slack like online chat, built with Meteor. https://rocket.chat/  | CoffeeScript | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.konecty.rocket.chat)   

### S  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[surespot](https://github.com/surespot/android)| surespot is a mobile messaging application that secures all messages using end-to-end encryption. https://www.surespot.me | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.twofours.surespot) 
[Signal](https://github.com/WhisperSystems/Signal-Android) | A secure calling and messaging app for Android. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.thoughtcrime.securesms)

### T  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Tutanota](https://github.com/tutao/tutanota) | Tutanota is the end-to-end encrypted mail client that enables you to communicate securely with anyone.  | JavaScript | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=de.tutao.tutanota)  
[Telegram Messenger](https://github.com/DrKLO/Telegram) | Telegram Messenger for Android https://telegram.org/ | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.telegram.messenger) 
[TintBrowser](https://github.com/Anasthase/TintBrowser) | Is an open-source browser for Android 4 and above | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.tint)

### U  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### V  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 [VideoFly](https://github.com/VideoFly/VideoFly)| VideoFly is a video calling application which enables you to stay in a video call while using other applications.| Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=example.com.videofly)  

### W  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[wechat](https://github.com/motianhuo/wechat) | 高仿微信 | | [![Get it on Third-Party](http://i.imgur.com/ppYJYe5.png)](https://raw.githubusercontent.com/motianhuo/wechat/master/WeChat/bin/WeChat.apk)   
[WiFi Walkie Talkie](https://github.com/js-labs/WalkieTalkie) | Simple application transmitting audio from mic to all devices running the same program on the same network segment. Use NSD for device discovery. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.jsl.wfwt)
[Wire](https://github.com/wireapp/wire) | Messenger application that encrypts end to end communication. | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.wire&hl=en)

### X  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
 | | | 

### Y  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Yaaic](https://github.com/pocmo/Yaaic) | Yaaic (Yet Another Android IRC Client) is as the name already says an Internet Relay Chat (IRC) client for Android devices. http://www.yaaic.org | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=org.yaaic)  

### Z  
App Name                   | Describe                  | Major Language             | Download 
:------------------------: | :------------------------ | :------------------------: | :------------------------: 
[Zulip Android](https://github.com/zulip/zulip-android) | Zulip Android app, Powerful open source group chat  https://www.zulip.org/ | Java | [![Get it on Google Play](http://i.imgur.com/7sq06lr.png)](https://play.google.com/store/apps/details?id=com.zulip.android)  
