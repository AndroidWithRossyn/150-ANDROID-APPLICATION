## SQLiteDemo
SQLite is a SQL database that stores data in a text file on a device. 
  
Some useful links:  
http://abhiandroid.com/database/sqlite  
https://www.tutorialspoint.com/android/android_sqlite_database.htm
