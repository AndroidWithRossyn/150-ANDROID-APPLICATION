#Animated Vector Drawable

This sample will demonstrate you, how to apply vector morphing operation to the vector drawable. 

It is recommended that first, you get the basic knowledge of vector drawable, vector paths and groups and path morphing operations before understanding this sample. I found [this](https://lewismcgeary.github.io/posts/animated-vector-drawable-pathMorphing/) article useful. (The example shown here and the example explained in this article are different.)

###Screenshot:
![Screenshot](https://github.com/kevalpatel2106/android-samples/blob/master/Animated%20Vector%20Drawables/assets/sample.gif)