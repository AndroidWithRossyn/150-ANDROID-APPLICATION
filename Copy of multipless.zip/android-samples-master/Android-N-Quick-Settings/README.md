# Android-N-Quick-Settings

This sample will show you how any android application can display a quick settings tile in the notification drawer. This will also display how application can respond the click on the Quick Settings Tile.

####[Here is the guide](https://codelabs.developers.google.com/codelabs/android-n-quick-settings/index.html?index=..%2F..%2Findex#0) for creating and managing the Quick Settings in Android 7.0 and higher.
