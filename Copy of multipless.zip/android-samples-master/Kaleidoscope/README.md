#Kaleidoscope View:

![smaple](https://github.com/kevalpatel2106/android-samples/blob/master/Kaleidoscope/assets/sample.gif?raw=true)
