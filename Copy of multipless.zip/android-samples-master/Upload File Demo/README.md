# Upload File Demo #

This project uses HttpUrlConnectio to upload the file using multipoart form data request.
