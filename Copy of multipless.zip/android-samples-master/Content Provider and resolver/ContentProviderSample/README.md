#Content Provider

- This project demonstrates how ot expose your application data to other applications using content provider. 

####What you will learn:
- Create content provider.
- Expose your SQLite database using simple content provider.
- Bind data to the list view using `SimpleCursorAdapter`.

####Sample App:
- Here is the [link](https://mega.nz/#!GJBAUI5L!A8bFkMSFZvxUoQda-h57hI1sHywm5H_AneV9-0G8J10) of the sample apk.

####Screen shot:
![Screenshot](https://github.com/kevalpatel2106/android-samples/tree/master/Content%20Provider%20and%20resolver/ContentProviderSample/assets/sample.png)
