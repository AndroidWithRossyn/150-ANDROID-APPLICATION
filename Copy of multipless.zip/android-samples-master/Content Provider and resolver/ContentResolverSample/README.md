#Content Resolver

- This project how you can read data other application's content provider. This application searches from the name using the content provider we created in [Content Provider Sample](https://github.com/kevalpatel2106/android-samples/tree/master/Content%20Provider%20and%20resolver/ContentProviderSample).

####What you will learn:
- How to retrieve data from the content provider asynchronously using cursor loader.

####Sample App:
- To get the demo of the application, you have to install [Content Provider Sample](https://github.com/kevalpatel2106/android-samples/tree/master/Content%20Provider%20and%20resolver/ContentProviderSample) application first.
- Here is the [link](https://mega.nz/#!iAQS2CTZ!XWR8s1S_nL5PQdqZndvQFshd-mUiOPAzlG0H7GjaUJE) of the sample apk.

####Screenshot:
![Screenshot](https://github.com/kevalpatel2106/android-samples/blob/master/Content%20Provider%20and%20resolver/ContentResolverSample/assets/sample.png)
