# list-countdown-timer-demo
![Screenshot](https://github.com/kevalpatel2106/android-samples/blob/master/Listview%20Countdown%20Timer/screenshot/screen-1.gif)

#What is this repo for?
* This repo demostrates how to make a recycler view, in which each row displays countdown timer.
* When the time is up, the row will automatically removed from the list.
