#Android Wear Notification Sample

#####This is the demo that explains how you can extend your existing notification to show on the android wearables and integrate some android wear specific features into it.

**FYI:** If you don't know how to connect android wear with your phone or you want to connect your android wear emulator with the physical device for testing and debugging purpose, visit [this](https://developer.android.com/training/wearables/apps/creating.html).