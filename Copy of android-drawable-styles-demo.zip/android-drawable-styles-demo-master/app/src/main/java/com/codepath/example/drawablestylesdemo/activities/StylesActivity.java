package com.codepath.example.drawablestylesdemo.activities;

import android.app.Activity;
import android.os.Bundle;

import com.example.drawablestylesdemo.R;

public class StylesActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_styles);
	}

}
