ownCloud Jelly Bean Workaround
==============================

Helper app to work around the problem of lost credentials at reboot time found
in devices with Android 4.1.x. 

Only needed for ownCloud apps installed from the Google Play Store.

See more information about the bug here: 
http://code.google.com/p/android/issues/detail?id=34880