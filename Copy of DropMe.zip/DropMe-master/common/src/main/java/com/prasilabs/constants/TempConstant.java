package com.prasilabs.constants;

/**
 * Created by prasi on 31/5/16.
 */
public class TempConstant
{
    public static final long VCAR = 5722646637445120L;
    public static final long VBIKE = 5639445604728832L;
}
