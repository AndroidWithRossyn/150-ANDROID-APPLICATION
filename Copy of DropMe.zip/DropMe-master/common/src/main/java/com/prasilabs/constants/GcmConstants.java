package com.prasilabs.constants;

/**
 * Created by prasi on 9/6/16.
 */
public class GcmConstants
{
    public static final String GCM_TOKEN_STR = "gcm_token";
    public static final String GCM_KEY_UPDATE_TIME_STR = "gcm_key_update_time";
    public static final String ID_KEY = "id";
    public static final String MESSAGE_KEY = "message";
    public static final String JOB_TYPE_KEY = "jobType";
}
