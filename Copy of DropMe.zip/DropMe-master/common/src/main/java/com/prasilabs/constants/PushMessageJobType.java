package com.prasilabs.constants;

/**
 * Created by prasi on 9/6/16.
 */
public class PushMessageJobType
{
    public static final String RIDE_FOUND_ALERT_STR = "ride_found_alert";
    public static final String LOCATION_SHARE_STR = "location_share";
}
