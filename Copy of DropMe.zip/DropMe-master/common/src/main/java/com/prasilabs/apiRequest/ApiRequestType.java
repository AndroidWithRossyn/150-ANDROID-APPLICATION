package com.prasilabs.apiRequest;

/**
 * Created by prasi on 10/3/16.
 */
public enum ApiRequestType
{
    POST,
    GET
}
