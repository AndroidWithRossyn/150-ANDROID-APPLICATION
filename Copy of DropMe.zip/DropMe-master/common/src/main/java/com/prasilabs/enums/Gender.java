package com.prasilabs.enums;

/**
 * Created by prasi on 30/5/16.
 */
public enum Gender
{
    Male,
    Female
}
