package com.prasilabs.enums;

/**
 * Created by prasi on 26/5/16.
 */
public enum LoginType
{
    FaceBook,
    GPlus
}
