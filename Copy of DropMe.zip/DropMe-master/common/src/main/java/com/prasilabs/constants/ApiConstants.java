package com.prasilabs.constants;

/**
 * Created by prasi on 13/6/16.
 */
public class ApiConstants
{
    public static final String SERVER_GOOGLE_API = "AIzaSyDo3LXdo7rZxENytQeq0HWM1yfupmNNOxU";
}
