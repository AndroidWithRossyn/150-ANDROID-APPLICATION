package com.prasilabs.enums;

/**
 * Created by prasi on 23/6/16.
 */
public enum CrashType {
    LOG,
    WARN,
    SEVERE,
    EXCEPTION
}
