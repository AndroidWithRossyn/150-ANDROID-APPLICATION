package com.prasilabs.enums;

/**
 * Created by prasi on 28/5/16.
 */
public enum VehicleType
{
    Car,
    Bike
}
