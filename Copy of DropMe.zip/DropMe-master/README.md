# DropMe (Support Ended) This project is now private and no more support/update has been provided
DropME android app with Google App Engine Server

DropMe is basically an android app with backend server hosted in GAE. 
It really focus on ride sharing, Where people can find or share their ride when they are going for office, or someother places.

This one is a real time app with uber like interface you can look for ride givers, call them, there by save your money.

![image](https://github.com/praslnx8/DropMe/blob/master/app/screenshot/map_view.jpg?raw=true)
![image](https://github.com/praslnx8/DropMe/blob/master/app/screenshot/select_ride2.jpg?raw=true)
![image](https://github.com/praslnx8/DropMe/blob/master/app/screenshot/notification.jpg?raw=true)
