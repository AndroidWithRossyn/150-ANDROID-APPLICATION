package com.prasilabs.dropme.backend.annotions;

/**
 * Created by prasi on 2/5/16.
 */

public @interface Admin
{

}
