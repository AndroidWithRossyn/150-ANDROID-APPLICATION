package com.prasilabs.dropme.backend.core;

/**
 * Created by prasi on 16/3/16.
 */
public class CoreController
{
    //TODO donot forget to change the cron file. (cron.xml)
    //TODO donot forget to change the enableSms. (SmsSender.java)
    public static boolean isDebug = true;
}
