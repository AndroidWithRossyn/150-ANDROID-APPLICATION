package com.prasilabs.dropme.backend.annotions;

/**
 * Created by prasi on 9/6/16.
 */
public @interface PushQ
{

}
