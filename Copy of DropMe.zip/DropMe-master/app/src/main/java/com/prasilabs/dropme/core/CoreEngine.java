package com.prasilabs.dropme.core;

/**
 * Created by prasi on 26/5/16.
 */
public abstract class CoreEngine
{

}
