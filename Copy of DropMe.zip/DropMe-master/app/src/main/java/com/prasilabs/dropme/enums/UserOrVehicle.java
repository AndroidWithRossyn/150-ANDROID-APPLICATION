package com.prasilabs.dropme.enums;

/**
 * Created by prasi on 27/5/16.
 */
public enum UserOrVehicle
{
    User,
    Vehicle
}
