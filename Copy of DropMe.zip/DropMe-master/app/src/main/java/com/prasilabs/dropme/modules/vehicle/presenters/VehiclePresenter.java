package com.prasilabs.dropme.modules.vehicle.presenters;

import android.content.Context;
import android.content.Intent;

import com.prasilabs.dropme.core.CorePresenter;

/**
 * Created by prasi on 28/5/16.
 */
public class VehiclePresenter extends CorePresenter
{

    @Override
    protected void onCreateCalled() {

    }

    @Override
    protected void broadCastRecieved(Context context, Intent intent) {

    }
}
