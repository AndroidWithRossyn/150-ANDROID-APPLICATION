package com.prasilabs.dropme.constants;

/**
 * Created by prasi on 1/7/16.
 */
public class ErrorCodes {
    public static final int TIME_OUT = 1;
    public static final int NOT_CONNECTED = 2;
    public static final int GENERAL = 3;
}
