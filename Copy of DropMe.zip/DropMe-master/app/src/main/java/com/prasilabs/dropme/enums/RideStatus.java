package com.prasilabs.dropme.enums;

/**
 * Created by prasi on 28/5/16.
 */
public enum  RideStatus
{
    User,
    Riding,
    Offering
}
