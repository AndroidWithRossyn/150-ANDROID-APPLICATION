package com.prasilabs.dropme.constants;

/**
 * Created by prasi on 27/5/16.
 */
public class LocationConstant
{
    public static final String CURRENT_LOC_STR = "current_loc";
    public static final String AGGREGATE_CURRENT_LOC_STR = "aggregate_current_loc";
    public static final String CURRENT_LOC_TIME_STR = "current_loc_time";
    public static final String LOC_NAME_STR = "loc_name";
}
