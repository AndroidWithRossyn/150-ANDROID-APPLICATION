package com.prasilabs.dropme.modules.vehicle.presenters;

import android.content.Context;
import android.content.Intent;

import com.prasilabs.dropme.core.CorePresenter;

/**
 * Created by prasi on 15/6/16.
 */
public class CreateVehiclePresenter extends CorePresenter {

    @Override
    protected void onCreateCalled() {

    }

    @Override
    protected void broadCastRecieved(Context context, Intent intent) {

    }
}
