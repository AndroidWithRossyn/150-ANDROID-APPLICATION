package org.ligi.survivalmanual.model

data class SearchResult(val file: String, val teaser: String)