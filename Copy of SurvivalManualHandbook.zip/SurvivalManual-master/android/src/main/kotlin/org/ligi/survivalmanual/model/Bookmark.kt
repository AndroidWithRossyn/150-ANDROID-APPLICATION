package org.ligi.survivalmanual.model

data class Bookmark(val url: String, val description: String, val excerpt: String)