package org.ligi.survivalmanual.viewholder

import android.support.v7.widget.RecyclerView
import android.widget.TextView

class TextContentViewHolder(val view: TextView) : RecyclerView.ViewHolder(view)