__This repo contains demo code for the following Tuts+ Android tutorial__:

## Streaming Video in Android Apps

* http://code.tutsplus.com/tutorials/streaming-video-in-android-apps--cms-19888

I'm adding the code here as an additional way for readers to use/ contribute to it.

The tutorial was written some time ago so the techniques in it may well be out of date - but I'm starting this repo with the source code as it was when written, so that anyone who read the tutorial then can see any subsequent changes clearly.

Feel free to use the code or to contribute to it (pull requests welcome) - I might update it at some point but don't hold your breath!
