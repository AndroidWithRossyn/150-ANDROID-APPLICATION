package github.nisrulz.sample.appshortcuts;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class StaticShortcutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_static_shortcut);
    }
}
