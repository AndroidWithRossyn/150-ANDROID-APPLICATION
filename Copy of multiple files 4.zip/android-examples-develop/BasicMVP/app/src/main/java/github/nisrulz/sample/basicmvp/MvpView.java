package github.nisrulz.sample.basicmvp;

/**
 * The interface MvpView.
 */
public interface MvpView {
  /**
   * Update user info text mvpView.
   *
   * @param info
   *     the info
   */
  void updateUserInfoTextView(String info);
}
