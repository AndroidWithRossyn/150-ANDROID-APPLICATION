<!-- * Please fill out the blanks below describing your issue * -->

**Do you want to request a *feature* or report a *bug*?**

**What is the current behavior?**

**If the current behavior is a bug, please provide the steps to reproduce.**
<!-- If you can, provide a link to a public repository which contains the files necessary to reproduce this. -->


**Any logs, error output, bugreport etc?**
<!-- * If it’s long, please paste to https://ghostbin.com/ and insert the link here.) * -->

**What is the expected behavior?**

**Any other comments?**


**What versions of software are you using?**
+ **Device Information:** 

+ **Android Version:** 

+ **Configuration Information:** 

+ **Misc:** 

<!-- * More related information if you have can provide * -->