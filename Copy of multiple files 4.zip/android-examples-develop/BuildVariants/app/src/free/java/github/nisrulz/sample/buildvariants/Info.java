package github.nisrulz.sample.buildvariants;

public class Info {

  public static String getTypeOfBuidl() {
    return "Free Build";
  }

}
