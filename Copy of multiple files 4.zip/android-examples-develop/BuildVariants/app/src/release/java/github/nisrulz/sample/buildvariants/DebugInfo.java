package github.nisrulz.sample.buildvariants;

public class DebugInfo {
  public static boolean isDebuggable() {
    return false;
  }
}
