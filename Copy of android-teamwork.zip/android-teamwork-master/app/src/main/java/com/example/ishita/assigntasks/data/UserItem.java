package com.example.ishita.assigntasks.data;

/**
 * Created by ishita on 11/3/16.
 */
public class UserItem {
}
