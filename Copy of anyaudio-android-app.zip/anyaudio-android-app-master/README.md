# AnyAudio
An Instant Music App

[![Gitter chat](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/Any-Audio/anyaudio-android-app?utm_source=share-link&utm_medium=link&utm_campaign=share-link) 

# ScreenShots
<img src="\Screenshots\present\anyaudio_presentaion_02.png" width="640px" height="480px" alt="Current Location Pointer">  <img src="\Screenshots\present\anyaudio_presentaion_05.png" width="640px" height="480px" alt="Location History">   <img src="\Screenshots\present\anyaudio_presentaion_06.png" width="640px" height="480px" alt="Setting">    <img src="\Screenshots\present\anyaudio_presentaion_07.png" width="640px" height="480px" alt="Login">
    <img src="\Screenshots\present\anyaudio_presentaion_08.png" width="640px" height="480px" alt="Login">
