package any.audio.Models;


public class ViewTypeModel {

    public int viewType;
    public String sectionTitle;
    public int index;

    public ViewTypeModel(int viewType, String sectionTitle, int index) {
        this.viewType = viewType;
        this.sectionTitle = sectionTitle;
        this.index = index;
    }
}
