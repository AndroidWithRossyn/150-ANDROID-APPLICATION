package any.audio.Interfaces;

/**
 * Created by Ankit on 10/7/2016.
 */
public interface StreamPrepareFailedListener {
    void onPrepareFailed();
}
