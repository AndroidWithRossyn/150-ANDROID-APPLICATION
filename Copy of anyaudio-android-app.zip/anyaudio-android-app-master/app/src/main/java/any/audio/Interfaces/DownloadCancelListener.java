package any.audio.Interfaces;

/**
 * Created by Ankit on 9/25/2016.
 */
public interface DownloadCancelListener {
    void onDownloadCancel(String taskID);
}
