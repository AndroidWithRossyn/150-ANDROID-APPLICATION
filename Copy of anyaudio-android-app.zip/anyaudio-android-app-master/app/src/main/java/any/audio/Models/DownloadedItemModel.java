package any.audio.Models;

/**
 * Created by Ankit on 2/10/2017.
 */
public class DownloadedItemModel {

    public String title;

    public DownloadedItemModel(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
