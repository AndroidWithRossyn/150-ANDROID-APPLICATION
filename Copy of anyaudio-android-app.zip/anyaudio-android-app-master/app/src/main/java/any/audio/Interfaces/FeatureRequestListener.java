package any.audio.Interfaces;

/**
 * Created by Ankit on 8/11/2016.
 */
public interface FeatureRequestListener {
    void onTaskTapped(String type,String video_id, String file_name);

}
