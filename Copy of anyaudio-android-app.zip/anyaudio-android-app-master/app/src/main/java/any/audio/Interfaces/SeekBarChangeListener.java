package any.audio.Interfaces;

/**
 * Created by Ankit on 10/6/2016.
 */
public interface SeekBarChangeListener {
    void onSeekTo(int seekToPosition);
}
