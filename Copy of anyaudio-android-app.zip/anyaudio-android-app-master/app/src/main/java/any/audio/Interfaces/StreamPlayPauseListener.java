package any.audio.Interfaces;

/**
 * Created by Ankit on 10/8/2016.
 */
public interface StreamPlayPauseListener {
    void onStateChange(boolean isStreaming);
}
