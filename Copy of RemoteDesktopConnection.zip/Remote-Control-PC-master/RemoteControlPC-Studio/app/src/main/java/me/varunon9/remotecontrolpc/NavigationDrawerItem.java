package me.varunon9.remotecontrolpc;

public class NavigationDrawerItem {
	public int icon;
	public String title;
	
	public NavigationDrawerItem (int icon, String title) {
		this.icon = icon;
		this.title = title;
	}
}
