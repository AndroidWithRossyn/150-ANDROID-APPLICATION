package me.varunon9.remotecontrolpc;

public interface CallbackReceiver {
     public void receiveData (Object result);
}
