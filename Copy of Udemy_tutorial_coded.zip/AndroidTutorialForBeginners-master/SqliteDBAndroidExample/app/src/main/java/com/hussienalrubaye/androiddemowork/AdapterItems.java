package com.hussienalrubaye.androiddemowork;

/**
 * Created by hussienalrubaye on 9/8/16.
 */

public class AdapterItems
{
    public   int ID;
    public  String UserName;
    public  String Password;
    //for news details
    AdapterItems( int ID, String UserName,String Password)
    {
        this. ID=ID;
        this. UserName=UserName;
        this. Password=Password;
    }
}
