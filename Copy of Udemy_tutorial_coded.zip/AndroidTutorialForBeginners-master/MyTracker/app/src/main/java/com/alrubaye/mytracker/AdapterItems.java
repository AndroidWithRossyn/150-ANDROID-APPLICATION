package com.alrubaye.mytracker;

/**
 * Created by hussienalrubaye on 9/26/16.
 */

public class AdapterItems
{

    public  String UserName;
    public  String PhoneNumber;
    //for news details
    AdapterItems(  String UserName,String PhoneNumber)
    {
        this. UserName=UserName;
        this. PhoneNumber=PhoneNumber;
    }
}
