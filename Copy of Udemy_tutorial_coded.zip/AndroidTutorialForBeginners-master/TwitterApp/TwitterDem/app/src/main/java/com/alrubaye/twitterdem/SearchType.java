package com.alrubaye.twitterdem;

/**
 * Created by hussienalrubaye on 11/13/16.
 */

public class SearchType {
    public static int MyFollowing=1;
    public static int OnePerson=2;
    public static int SearchIn=3;
}
