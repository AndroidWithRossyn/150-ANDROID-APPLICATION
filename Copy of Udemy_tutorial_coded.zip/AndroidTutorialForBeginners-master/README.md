## Snapped code for android Tutorial For Beginners PlayList in YouTube, check the videos Tutorial  [here](https://www.udemy.com/android-tutorial-for-beginners/?couponCode=ANDORIDGITHUB)



![main](http://attach.alruabye.net/androidTutorialForBeginners/androidTutorialForBeginners.png)
# androidTutorialForBeginners
