// Application Dependencies

import 'lodash';
import 'vertx3-eventbus-client';
import 'jsencrypt';
