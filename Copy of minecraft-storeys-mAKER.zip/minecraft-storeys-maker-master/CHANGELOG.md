## Change Log

### 2017/08/20

- This is the original first public release, used e.g. here: <a href="http://www.youtube.com/watch?feature=player_embedded&v=ZHHUB7R0gEo
" target="_blank"><img src="http://img.youtube.com/vi/ZHHUB7R0gEo/0.jpg" 
alt="Minecraft Stories Maker" width="480" height="360" border="10" /></a>
