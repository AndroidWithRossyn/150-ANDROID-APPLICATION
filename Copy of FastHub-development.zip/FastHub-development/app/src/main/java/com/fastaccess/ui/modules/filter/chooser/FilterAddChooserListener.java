package com.fastaccess.ui.modules.filter.chooser;

/**
 * Created by Kosh on 10 Apr 2017, 12:19 PM
 */

public interface FilterAddChooserListener {

    void onAddSelected();

    void onSearchSelected();
}
