package com.fastaccess.helper;

import android.support.annotation.Nullable;

/**
 * Created by Kosh on 18 Apr 2017, 10:57 PM
 */

public class ObjectsCompat {

    public static boolean nonNull(@Nullable Object obj) {
        return obj != null;
    }
}
