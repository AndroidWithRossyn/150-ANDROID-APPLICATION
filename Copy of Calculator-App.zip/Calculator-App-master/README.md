# A simple Android calculator app

Nothing special, I just made a very simple calculator app for android phones.   
![](http://i.imgur.com/F6a3As3.png)