- [ ] I have verified there are no duplicate active or recent bugs, questions, or requests.
- [ ] I have verified that I am using the latest version of AppUpdater.
- [ ] I have given my issue a non-generic title.
- [ ] I have read over the [README](https://github.com/javiersantos/AppUpdater/blob/master/README.md), [Wiki](https://github.com/javiersantos/AppUpdater/wiki) and [FAQs](https://github.com/javiersantos/AppUpdater/wiki/FAQs) (before asking questions on how to do something).

###### Details
 - PiracyChecker version: `2.x.x`
 - Device OS version: `7.1.1`
 - Device Manufacturer: `LG`
 - Device Name: `Nexus 5X`
 
###### Builder
```Java
new AppUpdater(this)
   ...
   .start();
```

###### Reproduction Steps

1.
2.
3.

###### Expected Result



###### Actual Result
