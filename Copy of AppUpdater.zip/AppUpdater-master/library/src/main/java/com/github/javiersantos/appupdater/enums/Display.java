package com.github.javiersantos.appupdater.enums;

public enum Display {
    DIALOG,
    SNACKBAR,
    NOTIFICATION
}
