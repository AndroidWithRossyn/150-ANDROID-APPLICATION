**Travel Mate**

+ Destinations
  + Most popular cities & Other cities
     + Description
     + Temperature details
     + Fun Facts
     + On map : Nearby hangout places, Monuments, Restaurants and Shopping places
     + City Trends (Most popular tweets of city during that time)
+ Travel
  + My Trips
     + Add new trip
     + Previous trips
  + Transport 
     + Train, Bus, Car
  + Hotel booking
  + online shopping
  + real time locator
+ Utilities
  + Share Contact (Share my contact or view someone's contact)
  + Checklist 
+ Emergency Contact
+ Sign in/ Sign out 
