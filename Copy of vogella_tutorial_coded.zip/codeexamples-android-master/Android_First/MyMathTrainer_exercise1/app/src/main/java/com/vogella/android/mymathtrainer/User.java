package com.vogella.android.mymathtrainer;

public class User {
    public String name;
    public boolean gender;

    public User(String name, boolean gender) {
        this.name = name;
        this.gender = gender;
    }

}
