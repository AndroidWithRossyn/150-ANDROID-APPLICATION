/**
 * All models retrieved from the API use their own ids (because they must be consistent with
 * tatoeba IDs and language abbreviations).
 */
package info.puzz.a10000sentences.models;
