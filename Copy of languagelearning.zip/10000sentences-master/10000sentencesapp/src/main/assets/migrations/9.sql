alter table annotation add column updated number;
