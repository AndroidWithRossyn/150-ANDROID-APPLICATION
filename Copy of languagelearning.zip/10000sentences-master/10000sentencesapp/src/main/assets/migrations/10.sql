alter table sentence_collection add column type text;
