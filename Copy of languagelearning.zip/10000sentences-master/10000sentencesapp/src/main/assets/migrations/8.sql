alter table sentence_collection add column skipped_count text;
