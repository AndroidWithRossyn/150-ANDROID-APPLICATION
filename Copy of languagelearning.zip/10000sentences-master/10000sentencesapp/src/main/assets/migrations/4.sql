alter table sentence_history add column collection_id text;
