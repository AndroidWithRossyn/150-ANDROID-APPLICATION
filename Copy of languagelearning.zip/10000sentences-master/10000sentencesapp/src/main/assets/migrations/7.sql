alter table sentence_collection add column annotation_count text;
