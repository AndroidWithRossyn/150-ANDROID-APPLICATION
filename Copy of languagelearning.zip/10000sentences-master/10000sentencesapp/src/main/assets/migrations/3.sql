alter table sentence_history add column previous_status integer;
alter table sentence_history add column time integer;
alter table sentence_history add column todo_count integer;
alter table sentence_history add column repeat_count integer;
alter table sentence_history add column done_count integer;
alter table sentence_history add column ignore_count integer;
