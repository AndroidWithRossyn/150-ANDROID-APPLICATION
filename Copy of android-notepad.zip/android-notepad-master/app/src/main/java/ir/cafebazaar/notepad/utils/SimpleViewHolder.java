package ir.cafebazaar.notepad.utils;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by MohMah on 8/18/2016.
 */
public class SimpleViewHolder extends RecyclerView.ViewHolder{
	public SimpleViewHolder(View itemView){
		super(itemView);
	}
}
