package com.brenopolanski.movies.event;

public class TwoPaneEvent {
    public final boolean twoPane;

    public TwoPaneEvent(boolean twoPane) {

        this.twoPane = twoPane;
    }
}
