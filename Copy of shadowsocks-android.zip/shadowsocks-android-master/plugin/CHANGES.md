* 0.2.0:
  * Refactor to AndroidX;
  * No longer depends on preference libraries.
* 0.1.1:
  * Rewritten in Kotlin;
  * Fix assert not working;
  * Min API 21;
  * Update support library version to 27.1.1.
* 0.0.4:
  * Enlarge text size of number pickers;
  * Update support library version to 26.0.0.
* 0.0.3:
  * Update support library version to 25.2.0.
* 0.0.2:
  * Add `getOrDefault` to `PluginOptions`;
  * Update support library version to 25.1.1.
* 0.0.1: Initial release.
