package com.i7play.videopapger.app

import com.crossbowffs.remotepreferences.RemotePreferenceProvider

/**
 * Created by Administrator on 2017/6/13.
 */
class MyPreferenceProvider : RemotePreferenceProvider("com.i7play.videopapger.app.preferences", arrayOf("main_prefs")){

}