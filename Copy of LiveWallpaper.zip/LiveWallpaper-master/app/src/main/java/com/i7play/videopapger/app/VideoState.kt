package com.i7play.videopapger.app

/**
 * Created by Administrator on 2017/6/8.
 */
enum class VideoState {
    NORMAL, DOWNLOAD, PAUSE, COMPLETED
}