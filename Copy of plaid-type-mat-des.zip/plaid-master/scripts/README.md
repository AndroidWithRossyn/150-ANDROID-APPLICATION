The files in this directory are only used for continuous integration and lint
purposes. They are not part of the Android app.
