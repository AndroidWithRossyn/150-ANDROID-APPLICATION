# android-wikipedia
Android app that retrieves 10 random pages from wikipedia
