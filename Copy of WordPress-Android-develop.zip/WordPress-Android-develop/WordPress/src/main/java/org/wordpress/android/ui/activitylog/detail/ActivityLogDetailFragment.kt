package org.wordpress.android.ui.activitylog.detail

import android.app.Activity.RESULT_OK
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProvider
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v4.app.Fragment
import android.text.Spannable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_log_item_detail.*
import org.wordpress.android.R
import org.wordpress.android.WordPress
import org.wordpress.android.fluxc.model.SiteModel
import org.wordpress.android.fluxc.tools.FormattableRange
import org.wordpress.android.ui.notifications.utils.FormattableContentClickHandler
import org.wordpress.android.ui.notifications.utils.NotificationsUtilsWrapper
import org.wordpress.android.ui.posts.BasicFragmentDialog
import org.wordpress.android.util.image.ImageManager
import org.wordpress.android.util.image.ImageType.AVATAR
import org.wordpress.android.viewmodel.activitylog.ACTIVITY_LOG_ID_KEY
import org.wordpress.android.viewmodel.activitylog.ACTIVITY_LOG_REWIND_ID_KEY
import org.wordpress.android.viewmodel.activitylog.ActivityLogDetailViewModel
import javax.inject.Inject

class ActivityLogDetailFragment : Fragment() {
    @Inject lateinit var viewModelFactory: ViewModelProvider.Factory
    @Inject lateinit var imageManager: ImageManager
    @Inject lateinit var notificationsUtilsWrapper: NotificationsUtilsWrapper
    @Inject lateinit var formattableContentClickHandler: FormattableContentClickHandler

    private lateinit var viewModel: ActivityLogDetailViewModel

    companion object {
        fun newInstance(): ActivityLogDetailFragment {
            return ActivityLogDetailFragment()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        (activity?.application as WordPress).component()?.inject(this)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        activity?.let { activity ->
            viewModel = ViewModelProviders.of(activity, viewModelFactory)
                    .get<ActivityLogDetailViewModel>(ActivityLogDetailViewModel::class.java)

            val intent = activity.intent
            val (site, activityLogId) = when {
                savedInstanceState != null -> {
                    val site = savedInstanceState.getSerializable(WordPress.SITE) as SiteModel
                    val activityLogId = savedInstanceState.getString(ACTIVITY_LOG_ID_KEY)
                    site to activityLogId
                }
                intent != null -> {
                    val site = intent.getSerializableExtra(WordPress.SITE) as SiteModel
                    val activityLogId = intent.getStringExtra(ACTIVITY_LOG_ID_KEY)
                    site to activityLogId
                }
                else -> throw Throwable("Couldn't initialize Activity Log view model")
            }

            viewModel.activityLogItem.observe(this, Observer { activityLogModel ->
                setActorIcon(activityLogModel?.actorIconUrl, activityLogModel?.showJetpackIcon)
                activityActorName.setTextOrHide(activityLogModel?.actorName)
                activityActorRole.setTextOrHide(activityLogModel?.actorRole)

                val spannable = activityLogModel?.content?.let {
                    notificationsUtilsWrapper.getSpannableContentForRanges(it, activityMessage, { range ->
                        viewModel.onRangeClicked(range)
                    }, false)
                }

                activityMessage.setTextOrHide(spannable)
                activityType.setTextOrHide(activityLogModel?.summary)

                activityCreatedDate.text = activityLogModel?.createdDate
                activityCreatedTime.text = activityLogModel?.createdTime

                if (activityLogModel != null) {
                    activityRewindButton.setOnClickListener {
                        viewModel.onRewindClicked(activityLogModel)
                    }
                }
            })

            viewModel.rewindAvailable.observe(this, Observer { available ->
                activityRewindButton.visibility = if (available == true) View.VISIBLE else View.GONE
            })

            viewModel.showRewindDialog.observe(this, Observer<ActivityLogDetailModel> { detailModel ->
                detailModel?.let { onRewindButtonClicked(it) }
            })

            viewModel.handleFormattableRangeClick.observe(this, Observer<FormattableRange> { range ->
                if (range != null) {
                    formattableContentClickHandler.onClick(activity, range)
                }
            })

            viewModel.start(site, activityLogId)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.activity_log_item_detail, container, false)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putSerializable(WordPress.SITE, viewModel.site)
        outState.putString(ACTIVITY_LOG_ID_KEY, viewModel.activityLogId)
    }

    fun onRewindConfirmed(rewindId: String) {
        val intent = activity?.intent?.putExtra(ACTIVITY_LOG_REWIND_ID_KEY, rewindId)
        activity?.setResult(RESULT_OK, intent)
        activity?.finish()
    }

    private fun setActorIcon(actorIcon: String?, showJetpackIcon: Boolean?) {
        when {
            actorIcon != null && actorIcon != "" -> {
                imageManager.loadIntoCircle(activityActorIcon, AVATAR, actorIcon)
                activityActorIcon.visibility = View.VISIBLE
                activityJetpackActorIcon.visibility = View.GONE
            }
            showJetpackIcon == true -> {
                activityJetpackActorIcon.visibility = View.VISIBLE
                activityActorIcon.visibility = View.GONE
            }
            else -> {
                imageManager.cancelRequestAndClearImageView(activityActorIcon)
                activityActorIcon.visibility = View.GONE
                activityJetpackActorIcon.visibility = View.GONE
            }
        }
    }

    private fun TextView.setTextOrHide(text: String?) {
        if (text != null) {
            this.text = text
            this.visibility = View.VISIBLE
        } else {
            this.visibility = View.GONE
        }
    }

    private fun TextView.setTextOrHide(text: Spannable?) {
        if (text != null) {
            this.text = text
            this.visibility = View.VISIBLE
        } else {
            this.visibility = View.GONE
        }
    }

    private fun onRewindButtonClicked(item: ActivityLogDetailModel) {
        val dialog = BasicFragmentDialog()
        item.rewindId?.let {
            dialog.initialize(it,
                    getString(R.string.activity_log_rewind_site),
                    getString(R.string.activity_log_rewind_dialog_message, item.createdDate, item.createdTime),
                    getString(R.string.activity_log_rewind_site),
                    getString(R.string.cancel))
            dialog.show(fragmentManager, it)
        }
    }
}
