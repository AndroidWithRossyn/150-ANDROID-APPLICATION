package org.wordpress.android.ui.activitylog.list

import android.view.ViewGroup
import org.wordpress.android.R

class FooterItemViewHolder(parent: ViewGroup) : ActivityLogViewHolder(parent, R.layout.activity_log_list_footer_item)
