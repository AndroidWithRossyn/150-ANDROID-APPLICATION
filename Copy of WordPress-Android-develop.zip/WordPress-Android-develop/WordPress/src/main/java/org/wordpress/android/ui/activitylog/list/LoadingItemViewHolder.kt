package org.wordpress.android.ui.activitylog.list

import android.view.ViewGroup
import org.wordpress.android.R

class LoadingItemViewHolder(parent: ViewGroup) : ActivityLogViewHolder(parent, R.layout.activity_log_list_loading_item)
