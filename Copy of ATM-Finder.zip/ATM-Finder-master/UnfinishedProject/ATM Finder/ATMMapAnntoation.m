//
//  ATMMapAnntoation.m
//  ATM Finder
//
//  Created by James on 02/07/2015.
//  Copyright (c) 2015 Buy n Large. All rights reserved.
//

#import "ATMMapAnntoation.h"

@implementation ATMMapAnntoation

@end
