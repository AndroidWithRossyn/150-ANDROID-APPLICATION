//
//  DetailATMTableViewCell.h
//  ATM Finder
//
//  Created by Archibald on 9/23/15.
//  Copyright © 2015 Buy n Large. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailATMTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *leftLabel;
@property (weak, nonatomic) IBOutlet UILabel *rightLabel;

@end
