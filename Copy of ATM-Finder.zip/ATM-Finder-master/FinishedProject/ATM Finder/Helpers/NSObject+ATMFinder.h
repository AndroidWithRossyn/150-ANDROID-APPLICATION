//
//  NSObject+ATMFinder.h
//  ATM Finder
//
//  Created by Archibald on 9/21/15.
//  Copyright © 2015 Buy n Large. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (ATMFinder)

-(id)valueOrNil;

@end
