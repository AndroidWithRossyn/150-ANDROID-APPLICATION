<?php
	session_start();
	ob_start();
?>