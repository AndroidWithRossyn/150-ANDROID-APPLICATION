package home.medico.com.medicohome;

public class Values {

    public static final String SENDER_ID = "146737795806";
}
