package home.medico.com.medicohome;

/**
 * Created by swati on 25/8/16.
 */
public interface Constants {

    String apilink="****";
}
