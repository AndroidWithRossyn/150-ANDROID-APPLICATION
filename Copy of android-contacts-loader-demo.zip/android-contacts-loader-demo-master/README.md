contacts-loader-example
=======================

Example of loading contacts into a listview using Content Providers

![Screen](http://i.imgur.com/4AHa6KN.png)