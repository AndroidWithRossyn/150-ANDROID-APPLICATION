package net.gouline.drawablesources.model;

import net.gouline.drawablesources.util.DrawableSource;

public interface Profile {
    String getName();

    DrawableSource getPicture();
}
