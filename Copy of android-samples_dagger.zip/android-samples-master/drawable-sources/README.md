Drawables Sources
=================

Sample Android application using drawable sources technique.

Read the full article [here][1].

[1]: http://blog.gouline.net/2015/07/06/drawables-in-null-safe-models/
