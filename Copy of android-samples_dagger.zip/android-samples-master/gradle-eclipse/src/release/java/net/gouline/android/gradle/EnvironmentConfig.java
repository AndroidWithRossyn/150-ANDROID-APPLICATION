package net.gouline.android.gradle;

/**
 * Environment-specific configuration.
 *
 * @author Mike Gouline
 *
 */
public interface EnvironmentConfig {

  public static final String ENVIRONMENT = "release";
}
