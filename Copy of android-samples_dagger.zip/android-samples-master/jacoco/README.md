JaCoCo
======

Sample Android application using [JaCoCo](http://www.eclemma.org/jacoco/).

Read the full article [here](http://blog.gouline.net/2015/06/23/code-coverage-on-android-with-jacoco/).

