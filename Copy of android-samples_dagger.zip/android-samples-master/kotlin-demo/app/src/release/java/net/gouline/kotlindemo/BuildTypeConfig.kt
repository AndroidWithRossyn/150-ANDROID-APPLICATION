package net.gouline.kotlindemo

/**
 * Release configuration.
 *
 * @author Mike Gouline
 */
object BuildTypeConfig {
    val LOG_MESSAGE = "RELEASE BUILD"
}