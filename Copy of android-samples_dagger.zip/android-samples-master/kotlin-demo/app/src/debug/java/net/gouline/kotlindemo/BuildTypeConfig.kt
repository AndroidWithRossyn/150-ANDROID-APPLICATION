package net.gouline.kotlindemo

/**
 * Debug configuration.
 */
object BuildTypeConfig {
    val LOG_MESSAGE = "DEBUG BUILD"
}