Kotlin Demo
===========

Sample Android application written in Kotlin. Enables Wi-Fi on the device and displays a list of base stations in the range with basic details about them.

Read the full article [here][1].

[1]: http://blog.gouline.net/2014/08/31/kotlin-the-swift-of-android/
