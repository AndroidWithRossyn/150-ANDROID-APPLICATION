Dagger 2 Demo
=============

Sample Android application using [Dagger 2](http://google.github.io/dagger/).

Read the full article [here](http://blog.gouline.net/2015/05/04/dagger-2-even-sharper-less-square/).

