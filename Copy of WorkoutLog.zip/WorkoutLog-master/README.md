# WorkoutLog
A minimalistic app for tracking your workouts

Lets you track your workouts by recording reps x weight you do
for each exercise. And reminds you your previous results when
you do the same exercise again.

Supports Android 2.2 and up, properly works with Android 6.
