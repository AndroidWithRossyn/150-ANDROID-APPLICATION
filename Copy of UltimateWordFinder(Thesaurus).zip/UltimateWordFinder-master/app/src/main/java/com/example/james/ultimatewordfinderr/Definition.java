package com.example.james.ultimatewordfinderr;

/**
 * Created by james on 4/09/2016.
 */
public class Definition {

    private String subject;
    private String definition;


    public Definition() {

    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDefinition() {
        return definition;
    }

    public void setDefinition(String definition) {
        this.definition = definition;
    }
}
