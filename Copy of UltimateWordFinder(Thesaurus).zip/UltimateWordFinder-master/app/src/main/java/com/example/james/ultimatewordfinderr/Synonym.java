package com.example.james.ultimatewordfinderr;

public class Synonym {

    private String word;
    private int score;

    public Synonym() {

    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
