package com.example.james.ultimatewordfinderr;

import java.util.ArrayList;

public interface DatamuseAPIResultsListener {
    public void onSynonymResults(ArrayList<String> synonyms);
}
