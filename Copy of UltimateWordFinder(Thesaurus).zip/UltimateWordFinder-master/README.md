[![Waffle.io - Columns and their card count](https://badge.waffle.io/CCninja86/UltimateWordFinder.png?columns=all)](https://waffle.io/CCninja86/UltimateWordFinder?utm_source=badge) [![Build Status](https://travis-ci.org/CCninja86/UltimateWordFinder.svg?branch=master)](https://travis-ci.org/CCninja86/UltimateWordFinder)

This project is licensed under the terms of the GPL-2.0 license.

### Download

1. Before you download the app, you must opt-in to the Beta here: https://play.google.com/apps/testing/nz.ac.aut.ultimatewordfinderr
2. After you have opted-in to the Beta, you can download the app on the Google Play store here: https://play.google.com/store/apps/details?id=nz.ac.aut.ultimatewordfinderr
