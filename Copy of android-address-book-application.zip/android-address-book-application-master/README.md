# Android Address Book Application

This is a simple implementation that stores a user's name, telephone number and email address in a
SQLite DB.

This is a project I did whilst at University when I took the Introduction to Android Programming module.
