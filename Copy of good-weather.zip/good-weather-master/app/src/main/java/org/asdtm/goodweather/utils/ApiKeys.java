package org.asdtm.goodweather.utils;

public class ApiKeys {

    /**
     * API key for http://openweathermap.org/api
     */
    public static final String OPEN_WEATHER_MAP_API_KEY = "1487dd8a93bfd85d278d9ac8dcfee94c";
}
