'use strict';

export const repairShop = {
  repairOrders: null
};
