'use strict';

import { combineReducers } from 'redux';

import repairShop from './repairShopReducer';

export default combineReducers({ repairShop });
