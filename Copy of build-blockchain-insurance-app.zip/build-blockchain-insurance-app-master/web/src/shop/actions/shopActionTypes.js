'use strict';

export const SET_SHOP_TYPE = 'SET_SHOP_TYPE';

export const SUBMIT_PRODUCT = 'SUBMIT_PRODUCT';
