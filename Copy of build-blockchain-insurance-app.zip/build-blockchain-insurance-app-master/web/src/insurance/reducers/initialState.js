'use strict';

export const claimProcessing = {
  claims: null
};

export const contractTemplates = {
  contractTypes: null
};

export const contracts = null;

export const userMgmt = {
  new: true,
  user: undefined
};
