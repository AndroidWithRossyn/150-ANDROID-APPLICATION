package com.kickstarter.ui.data;

public enum Newsletter {
  ALL,
  ALUMNI,
  ARTS,
  FILMS,
  GAMES,
  HAPPENING,
  INVENT,
  PROMO,
  READS,
  WEEKLY
}
