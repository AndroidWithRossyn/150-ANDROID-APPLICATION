package com.kickstarter.ui.data

enum class Mailbox(val type: String) {
  INBOX("inbox"),
  SENT("sent")
}
