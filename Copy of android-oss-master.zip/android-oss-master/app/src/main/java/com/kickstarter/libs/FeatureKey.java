package com.kickstarter.libs;

public final class FeatureKey {
  private FeatureKey() {}

}
