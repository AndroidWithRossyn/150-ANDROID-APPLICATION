package com.kickstarter.viewmodels.inputs;

public interface DownloadBetaViewModelInputs {
}
