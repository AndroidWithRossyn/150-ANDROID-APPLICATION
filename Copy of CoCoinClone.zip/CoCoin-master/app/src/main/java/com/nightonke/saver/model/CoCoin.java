package com.nightonke.saver.model;

/**
 * Created by Weiping on 2016/1/21.
 */

public class CoCoin {

    public static String APPLICATION_ID = "9d30e7692a56a79d7600b95cbff43283";

}
