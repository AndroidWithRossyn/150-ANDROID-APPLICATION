package com.matburt.mobileorg;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class ItemViewHolder extends RecyclerView.ViewHolder {

    public ItemViewHolder(View view) {
        super(view);
    }
}