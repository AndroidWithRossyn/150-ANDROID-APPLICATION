package com.matburt.mobileorg;

import android.view.View;

public interface SwipeInterface {

    void left2right(View v);

    void right2left(View v);

}
