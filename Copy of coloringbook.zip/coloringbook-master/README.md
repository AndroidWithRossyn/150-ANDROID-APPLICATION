# Coloring Book
There is an example for using SVG images in Android

Used libraries from:  
https://github.com/Pixplicity/sharp  
https://github.com/chrisbanes/PhotoView  
