Given(/^I am on the Home screen$/) do
  @screens.home.await
end
